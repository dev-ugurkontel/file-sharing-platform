﻿using System;

namespace betv1.Models
{
    public class AccountsModel : ApiServiceModel
    {
        public int      ID                  { get; set; }
        public string   UserName            { get; set; }
        public string   EMail               { get; set; }
        public string   HashPassword        { get; set; }
        public byte     AccountRole         { get; set; }
        public decimal  Balance             { get; set; }
        public bool     IsLoggedIn          { get; set; }
        public DateTime RegisteredDate      { get; set; }
        public string   AccountGUID         { get; set; }

        // DataTables
        public string   RegisteredDateStr   { get; set; }

        // Others
        public byte         Action          { get; set; }
    }
}