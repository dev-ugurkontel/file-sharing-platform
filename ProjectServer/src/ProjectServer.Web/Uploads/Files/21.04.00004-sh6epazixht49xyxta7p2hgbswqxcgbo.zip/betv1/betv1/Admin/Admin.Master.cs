﻿using System;
using System.Web;
using System.Web.UI;

namespace betv1.Admin
{
    public partial class Admin : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //body.Attributes.Add("style", "display: none");
        }
    }
}