﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace betv1
{
    public class Global : HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            RegisterRoutes(RouteTable.Routes);
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            var currentRequest = HttpContext.Current.Request.Url.AbsolutePath;

            if (currentRequest.Contains("api/v1/bets"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Bets");
            }
            else if (currentRequest.Contains("api/v1/coupon"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Coupon");
            }
            else if (currentRequest.Contains("api/v1/auth"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Auth");
            }
            else if (currentRequest.Contains("api/v1/user/balance"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Balance");
            }
            else if (currentRequest.Contains("api/v1/competition/count"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/CompetitionCount");
            }
            else if (currentRequest.Contains("api/v1/register"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Register");
            }
            else if (currentRequest.Contains("api/v1/verify/recaptchaV3"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/RecaptchaV3Vverify");
            }
            else if (currentRequest.Contains("api/v1/user/coupons"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Coupons");
            }
            else if (currentRequest.Contains("api/v1/user/coupon/details"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/CouponDetails");
            }
            else if (currentRequest.Contains("api/v1/user/recovery/password"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/ResetPassword");
            }
            else if (currentRequest.Contains("api/v1/user/deposit"))
            {
                HttpContext.Current.RewritePath("/Api/v1/DepositRequest.ashx/ProcessRequest");
            }
            else if (currentRequest.Contains("api/v1/user/withdraw"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Withdraw");
            }
            else if (currentRequest.Contains("api/v1/user/history/deposits"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/OldDepositRequests");
            }
            else if (currentRequest.Contains("api/v1/user/history/withdraws"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/OldWithdrawRequests");
            }
            else if (currentRequest.Contains("api/v1/user/history/deposit/cancel"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/CancelDepositRequests");
            }
            else if (currentRequest.Contains("api/v1/user/history/withdraw/cancel"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/CancelWithdrawRequests");
            }
            else if (currentRequest.Contains("api/v1/user/settings"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Settings");
            }
            else if (currentRequest.Contains("api/v1/user/profile"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Profile");
            }
            else if (currentRequest.Contains("api/v1/user/logout"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Main.asmx/Logout");
            }
            else if (currentRequest.Contains("api/v1/manage/sports"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Sports");
            }
            else if (currentRequest.Contains("api/v1/manage/sport/create"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/SportCreate");
            }
            else if (currentRequest.Contains("api/v1/manage/competition/count"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/CompetitionCount");
            }
            else if (currentRequest.Contains("api/v1/manage/sport/action"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/SportAction");
            }
            else if (currentRequest.Contains("api/v1/manage/sport/update"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/SportUpdate");
            }
            else if (currentRequest.Contains("api/v1/manage/sport/bet"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Sport");
            }
            else if (currentRequest.Contains("api/v1/manage/deposits"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Deposits");
            }
            else if (currentRequest.Contains("api/v1/manage/withdraws"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Withdraws");
            }
            else if (currentRequest.Contains("api/v1/manage/deposit/action"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/DepositAction");
            }
            else if (currentRequest.Contains("api/v1/manage/withdraw/action"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/WithdrawAction");
            }
            else if (currentRequest.Contains("api/v1/manage/sport/finalize/bet"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/FinalizeBet");
            }
            else if (currentRequest.Contains("api/v1/manage/sport/finalize/score"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/FinalizeBetScore");
            }
            else if (currentRequest.Contains("api/v1/manage/coupons"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Coupons");
            }
            else if (currentRequest.Contains("api/v1/manage/coupon/action"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/CouponAction");
            }
            else if (currentRequest.Contains("api/v1/manage/accounts"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Accounts");
            }
            else if (currentRequest.Contains("api/v1/manage/account/action"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/AccountAction");
            }
            else if (currentRequest.Contains("api/v1/manage/account/member"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Account");
            }
            else if (currentRequest.Contains("api/v1/manage/account/update"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/AccountUpdate");
            }
            else if (currentRequest.Contains("api/v1/manage/account/balance/history"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/AccountBalanceHistory");
            }
            else if (currentRequest.Contains("api/v1/manage/auth"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Auth");
            }
            else if (currentRequest.Contains("api/v1/manage/account/auth/history"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/AccountLoginHistory");
            }
            else if (currentRequest.Contains("api/v1/manage/dashboard"))
            {
                HttpContext.Current.RewritePath("/Api/v1/Admin.asmx/Dashboard");
            }




        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }

        private void RegisterRoutes(RouteCollection routes)
        {
            // @@@
            // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ S > SITE @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            // @@@



            // ######################################## S > General ########################################
            // General > Index
            routes.MapPageRoute("s-index",
                                "",
                                "~/Index.aspx");



            // ######################################## S > Sports ########################################
            // Sports > Sport
            routes.MapPageRoute("s-sport",
                                "sport",
                                "~/Views/Sports/Sport.aspx");



            // ######################################## S > Accounts ########################################
            // Accounts > Login
            routes.MapPageRoute("s-login",
                                "account/login",
                                "~/Views/Accounts/Login.aspx");

            // Accounts > Register
            routes.MapPageRoute("s-register",
                                "account/register",
                                "~/Views/Accounts/Register.aspx");

            // Accounts > Coupons
            routes.MapPageRoute("s-coupons",
                                "account/coupons",
                                "~/Views/Accounts/Coupons.aspx");

            // Accounts > Settings
            routes.MapPageRoute("s-settings",
                                "account/settings",
                                "~/Views/Accounts/Settings.aspx");

            // Accounts > Deposit
            routes.MapPageRoute("s-deposit",
                                "account/deposit",
                                "~/Views/Accounts/Deposit.aspx");

            // Accounts > Withdraw
            routes.MapPageRoute("s-withdraw",
                                "account/withdraw",
                                "~/Views/Accounts/Withdraw.aspx");

            // Accounts > User / userName
            routes.MapPageRoute("s-user",
                                "user/{userName}",
                                "~/Views/Accounts/Users.aspx");




            // ######################################## S > Recovery ########################################
            // Recovery > Reset Password
            routes.MapPageRoute("s-reset-password",
                                "recovery/reset-password",
                                "~/Views/Recovery/Reset-password.aspx");



            // ######################################## S > Pages ########################################
            // Pages > Register
            routes.MapPageRoute("s-terms-of-use",
                                "page/terms-of-use",
                                "~/Views/Pages/Terms-of-use.aspx");

            // Pages > Blog
            routes.MapPageRoute("s-blog",
                                "page/blog",
                                "~/Views/Pages/Blog.aspx");



            // ######################################## S > Errors ########################################
            // Errors > 400
            routes.MapPageRoute("s-error-400",
                                "error/400",
                                "~/Views/Errors/400.aspx");

            // Errors > 401
            routes.MapPageRoute("s-error-401",
                                "error/401",
                                "~/Views/Errors/401.aspx");

            // Errors > 403
            routes.MapPageRoute("s-error-403",
                                "error/403",
                                "~/Views/Errors/403.aspx");

            // Errors > 404
            routes.MapPageRoute("s-error-404",
                                "error/404",
                                "~/Views/Errors/404.aspx");

            // Errors > 405
            routes.MapPageRoute("s-error-405",
                                "error/405",
                                "~/Views/Errors/405.aspx");

            // Errors > 408
            routes.MapPageRoute("s-error-408",
                                "error/408",
                                "~/Views/Errors/408.aspx");

            // Errors > 500
            routes.MapPageRoute("s-error-500",
                                "error/500",
                                "~/Views/Errors/500.aspx");

            // Errors > 502
            routes.MapPageRoute("s-error-502",
                                "error/502",
                                "~/Views/Errors/502.aspx");

            // Errors > 503
            routes.MapPageRoute("s-error-503",
                                "error/503",
                                "~/Views/Errors/503.aspx");

            // Errors > 504
            routes.MapPageRoute("s-error-504",
                                "error/504",
                                "~/Views/Errors/504.aspx");




            // @@@
            // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ A > ADMIN @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            // @@@



            // ######################################## A > General ########################################
            // General > Index
            routes.MapPageRoute("a-index",
                                "manage",
                                "~/Admin/Index.aspx");



            // ######################################## A > Pages ########################################
            // Pages > Dashboard
            routes.MapPageRoute("a-dashboard",
                                "manage/pages/dashboard",
                                "~/Admin/Views/Pages/Dashboard.aspx");



            // ######################################## A > Sports ########################################
            // Spots > Sports
            routes.MapPageRoute("a-sports",
                                "manage/sports",
                                "~/Admin/Views/Sports/Sports.aspx");

            // Spots > Actions > Create
            routes.MapPageRoute("a-sports-create",
                                "manage/sports/actions/create",
                                "~/Admin/Views/Sports/Actions/Create.aspx");

            // Spots > Actions > Edit
            routes.MapPageRoute("a-sports-edit",
                                "manage/sports/actions/edit/{BetGUID}",
                                "~/Admin/Views/Sports/Actions/Edit.aspx");

            // Spots > Actions > Finalize
            routes.MapPageRoute("a-sports-finalize",
                                "manage/sports/actions/finalize/{BetGUID}",
                                "~/Admin/Views/Sports/Actions/Finalize.aspx");



            // ######################################## A > Deposits ########################################
            // Deposits > Pending
            routes.MapPageRoute("a-deposits-pending",
                                "manage/deposits/pending",
                                "~/Admin/Views/Deposits/Pending.aspx");

            // Deposits > Successful
            routes.MapPageRoute("a-deposits-successful",
                                "manage/deposits/successful",
                                "~/Admin/Views/Deposits/Successful.aspx");

            // Deposits > Unsuccessful
            routes.MapPageRoute("a-deposits-unsuccessful",
                                "manage/deposits/unsuccessful",
                                "~/Admin/Views/Deposits/Unsuccessful.aspx");

            // Deposits > Canceled
            routes.MapPageRoute("a-deposits-canceled",
                                "manage/deposits/canceled",
                                "~/Admin/Views/Deposits/Canceled.aspx");



            // ######################################## A > Withdraws ########################################
            // Withdraws > Pending
            routes.MapPageRoute("a-withdraws-pending",
                                "manage/withdraws/pending",
                                "~/Admin/Views/Withdraws/Pending.aspx");

            // Withdraws > Successful
            routes.MapPageRoute("a-withdraws-successful",
                                "manage/withdraws/successful",
                                "~/Admin/Views/Withdraws/Successful.aspx");

            // Withdraws > Unsuccessful
            routes.MapPageRoute("a-withdraws-unsuccessful",
                                "manage/withdraws/unsuccessful",
                                "~/Admin/Views/Withdraws/Unsuccessful.aspx");

            // Withdraws > Canceled
            routes.MapPageRoute("a-withdraws-canceled",
                                "manage/withdraws/canceled",
                                "~/Admin/Views/Withdraws/Canceled.aspx");



            // ######################################## A > Coupons ########################################
            // Coupons > Pending
            routes.MapPageRoute("a-coupons-pending",
                                "manage/coupons/pending",
                                "~/Admin/Views/Coupons/Pending.aspx");

            // Coupons > Successful
            routes.MapPageRoute("a-coupons-successful",
                                "manage/coupons/successful",
                                "~/Admin/Views/Coupons/Successful.aspx");

            // Coupons > Unsuccessful
            routes.MapPageRoute("a-coupons-unsuccessful",
                                "manage/coupons/unsuccessful",
                                "~/Admin/Views/Coupons/Unsuccessful.aspx");



            // ######################################## A > Accounts ########################################
            // Accounts > Accounts
            routes.MapPageRoute("a-accounts",
                                "manage/accounts",
                                "~/Admin/Views/Accounts/Accounts.aspx");

            // Accounts > Actions > Edit
            routes.MapPageRoute("a-accounts-edit",
                                "manage/accounts/edit/{AccountGUID}",
                                "~/Admin/Views/Accounts/Actions/Edit.aspx");





        }
    }
}