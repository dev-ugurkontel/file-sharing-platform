﻿using System;

namespace betv1.Models
{
    public class TournamentsModel
    {
        public Int16    ID                  { get; set; }
        public byte     BetTypeID           { get; set; }
        public string   TournamentName      { get; set; }
        public decimal  TournamentCommision { get; set; }
        public string   TournamentIconPath  { get; set; }
        public DateTime LastUpdateDate      { get; set; }

        // DataTables
        public string   LastUpdateDateStr   { get; set; }
    }
}