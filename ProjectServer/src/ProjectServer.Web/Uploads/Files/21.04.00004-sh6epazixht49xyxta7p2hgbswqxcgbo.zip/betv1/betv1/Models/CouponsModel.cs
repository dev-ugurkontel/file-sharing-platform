﻿using System;

namespace betv1.Models
{
    public class CouponsModel : ApiServiceModel
    {
        public long     ID                      { get; set; }
        public int      AccountID               { get; set; }
        public decimal  WinningRate             { get; set; }
        public decimal  AmountPlayed            { get; set; }
        public decimal  EarnedAmountWithTax     { get; set; }
        public decimal  EarnedAmountNoTax       { get; set; }
        public byte     CouponStatus            { get; set; }
        public DateTime CreatedDate             { get; set; }
        public DateTime LastUpdateDate          { get; set; }
        public string   CouponGUID              { get; set; }

        // DataTables
        public string   CreatedDateStr          { get; set; }
        public string   LastUpdateDateStr       { get; set; }
        public string   WinningRateStr          { get; set; }
        public string   AmountPlayedStr         { get; set; }
        public string   EarnedAmountWithTaxStr  { get; set; }
        public string   EarnedAmounNoTaxStr     { get; set; }

        // API
        public long     BetAmount               { get; set; }
        public long     CouponID                { get; set; }

        // Others
        public string   UserName                { get; set; }
        public decimal  Balance                 { get; set; }
    }
}