﻿using System;

namespace betv1.Models
{
    public class CouponDetailsModel
    {
        public long     ID                  { get; set; }
        public long     BetID               { get; set; }
        public DateTime AddedDate           { get; set; }
        public string   SelectedBetOption   { get; set; }
        public decimal  WinningRate         { get; set; }
        public byte     CouponDetailStatus  { get; set; }

        // DataTables
        public string   AddedDateStr        { get; set; }
    }
}