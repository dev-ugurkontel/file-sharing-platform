﻿using System.Configuration;
using System.Data.SqlClient;

namespace betv1.Libraries
{
    public class DatabaseConnection
    {
        public SqlConnection Connect(Database type)
        {
            SqlConnection conn = null;
            switch (type)
            {
                // Main Database
                case Database.Main:
                    conn = new SqlConnection(ConfigurationManager.ConnectionStrings["Main"].ConnectionString);
                    break;
            }
            return conn;
        }

        public enum Database
        {
            Main = 1
        }
    }
}