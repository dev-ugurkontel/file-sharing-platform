﻿using System;

namespace betv1.Models
{
    public class BalanceHistoriesModel : ApiServiceModel
    {
        public long     ID              { get; set; }
        public int      AccountID       { get; set; }
        public decimal  OldBalance      { get; set; }
        public decimal  CurrentBalance  { get; set; }
        public DateTime CreatedDate     { get; set; }

        // Others
        public string   AccountGUID     { get; set; }
    }
}