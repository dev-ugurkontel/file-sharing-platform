﻿using System;

namespace betv1.Models
{
    public class BetsModel : BasketballBetOptionsModel
    {
        public byte     BetTypeID               { get; set; }
        public Int16    TournamentID            { get; set; }
        public int      AdminID                 { get; set; }
        public decimal  BetCommission           { get; set; }
        public DateTime BetStartDate            { get; set; }
        public DateTime BetEndDate              { get; set; }
        public new DateTime LastUpdateDate      { get; set; }
        public bool     IsOpen                  { get; set; }
        public decimal  MinAmount               { get; set; }
        public decimal  MaxAmount               { get; set; }
        public string   BetName                 { get; set; }
        public string   BetCode                 { get; set; }
        public byte     MinPlayableMatches      { get; set; }
        public string   BetDescription          { get; set; }
        public Int16    TeamOneHalfTimeScore    { get; set; }
        public Int16    TeamOneFullTimeScore    { get; set; }
        public Int16    TeamTwoHalfTimeScore    { get; set; }
        public Int16    TeamTwoFullTimeScore    { get; set; }
        public string   BetGUID                 { get; set; }

        // API
        public new string   message             { get; set; }
        public new int      status              { get; set; }

        // DataTables
        public string   BetStartDateStr         { get; set; }
        public string   BetEndDateStr           { get; set; }

        // Others
        public decimal  BetTypeCommission       { get; set; }
        public decimal  TournamentCommision     { get; set; }
        public string   BetTypeName             { get; set; }
        public string   TournamentName          { get; set; }
        public byte     Action                  { get; set; }
    }
}