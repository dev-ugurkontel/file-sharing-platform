﻿using System;

namespace betv1.Models
{
    public class FootballBetOptionsModel
    {
        public long     ID              { get; set; }
        public long     BetID           { get; set; }
        public DateTime CreatedDate     { get; set; }
        public DateTime LastUpdateDate  { get; set; }
        public string _01 { get; set; }
        public string _02 { get; set; }
        public string _03 { get; set; }
        public string _04 { get; set; }
        public string _05 { get; set; }
        public string _06 { get; set; }
        public string _07 { get; set; }
        public string _08 { get; set; }
        public string _09 { get; set; }
        public string _10 { get; set; }
        public string _11 { get; set; }
        public string _12 { get; set; }
        public string _13 { get; set; }
        public string _14 { get; set; }
        public string _15 { get; set; }
        public string _16 { get; set; }
        public string _17 { get; set; }
        public string _18 { get; set; }
        public string _19 { get; set; }
        public string _20 { get; set; }
        public string _21 { get; set; }
        public string _22 { get; set; }
        public string _23 { get; set; }
        public string _24 { get; set; }
        public string _25 { get; set; }
        public string _26 { get; set; }

        // DataTables
        public string CreatedDateStr    { get; set; }
        public string LastUpdateDateStr { get; set; }
    }
}