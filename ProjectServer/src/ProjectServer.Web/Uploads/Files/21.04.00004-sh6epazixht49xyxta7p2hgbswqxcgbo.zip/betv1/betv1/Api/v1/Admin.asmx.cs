﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using betv1.Libraries;
using betv1.Models;
using Newtonsoft.Json;
using static betv1.Libraries.DatabaseConnection;
using static betv1.Libraries.ExternalFunctions;

namespace betv1.Api.v1
{
    /// <summary>
    /// Web Services API v1 Admin methods
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    [ScriptService]
    public class Admin : WebService
    {
        // Database Connections
        SqlConnection mainDatabase = new DatabaseConnection().Connect(Database.Main);

        // Nested Database Connections
        SqlConnection mainDatabaseNested = new DatabaseConnection().Connect(Database.Main);

        string authenticationFailed     = "authentication failed";
        string requestFailed            = "request failed";
        string serviceOffline           = "api v1 services are now offline";
        string authKey                  = ConfigurationManager.AppSettings["AuthKey"];

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Auth(   string eMail,
                            string password,
                            string pin,
                            string data)
        {
            var accounts        = new List<AdminsModel>();
            var wrongRequests   = new List<AdminsModel>();

            var wrongRequest    = new AdminsModel
            {
                message         = "unable to respond to incorrect request",
                status          = 2
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (eMail.Length    >= 6    &&
                    eMail.Length    <= 150  &&
                    password.Length >= 6    &&
                    password.Length <= 32   &&
                    pin.Length      >= 4    &&
                    pin.Length      <= 32)
                {
                    string token    = AesOperation.EncryptString(authKey, GenerateString(256));

                    var account     = new AdminsModel
                    {
                        message     = authenticationFailed,
                        status      = -1
                    };

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_postAdminAuth",   mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@HashEMail",       Aes(Operation.Encrypt, eMail)));
                        cmd.Parameters.Add(new SqlParameter("@HashPassword",    Aes(Operation.Encrypt, password)));
                        cmd.Parameters.Add(new SqlParameter("@HashPin",         Aes(Operation.Encrypt, pin)));
                        cmd.Parameters.Add(new SqlParameter("@Token",           token));
                        cmd.Parameters.Add(new SqlParameter("@Data",            data));
                        cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   GetIpAddress()));

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            int d = Convert.ToInt32(dr["Result"]);
                            if (d == 1)
                            {
                                account             = new AdminsModel
                                {
                                    ID              = Convert.ToInt32(dr["ID"]),
                                    EMail           = Aes(Operation.Decrypt, dr["EMail"].ToString()),
                                    AdminRole       = Convert.ToByte(dr["AdminRole"]),
                                    RegisteredDate  = Convert.ToDateTime(dr["RegisteredDate"]),
                                    Token           = token,
                                    ExpiredDate     = Convert.ToDateTime(dr["ExpiredDate"]),
                                    message         = "authentication was successfully",
                                    status          = 1
                                };
                            }
                            else if (d == 3)
                            {
                                account     = new AdminsModel
                                {
                                    message = authenticationFailed,
                                    status  = 3
                                };
                            }
                        }

                        accounts.Add(account);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(accounts);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// api/v1/bets (getBets)
        /// </summary>
        /// <param name="betTypeID">Bet type id, 1 for football, 2 for basketball</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Sports(object token)
        {
            try
            {
                bool clearCheck     = true;
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var bets    = new List<BetsModel>();

                var bet1    = new BetsModel
                {
                    message = "no upcoming competition found",
                    status  = -1
                };

                bets.Add(bet1);
            
                using (mainDatabase)
                {
                    SqlCommand cmd = new SqlCommand("usp_a_postSports",     mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                    }                    

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) bets.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            bet1 = new BetsModel
                            {
                                ID                  = Convert.ToInt64(dr["ID"]),
                                BetCode             = dr["BetCode"].ToString(),
                                BetTypeID           = Convert.ToByte(dr["BetTypeID"]),
                                BetName             = dr["BetName"].ToString(),
                                BetTypeName         = dr["BetTypeName"].ToString(),
                                TournamentName      = dr["TournamentName"].ToString(),
                                BetCommission       = Convert.ToDecimal(dr["BetCommission"]),
                                BetTypeCommission   = Convert.ToDecimal(dr["BetTypeCommission"]),
                                TournamentCommision = Convert.ToDecimal(dr["TournamentCommision"]),
                                BetStartDate        = Convert.ToDateTime(dr["BetStartDate"]),
                                BetEndDate          = Convert.ToDateTime(dr["BetEndDate"]),
                                LastUpdateDate      = Convert.ToDateTime(dr["LastUpdateDate"]),
                                IsOpen              = Convert.ToBoolean(dr["IsOpen"]),
                                BetGUID             = dr["BetGUID"].ToString(),
                                message             = "request is successfully",
                                status              = 1
                            };
                            bets.Add(bet1);
                        }
                        else
                        {
                            bet1        = new BetsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            bets.Add(bet1);
                        }                        

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(bets);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// api/v1/manage/sport/create (postBet)
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void SportCreate(object data)
        {
            var bets            = new List<BetsModel>();
            var wrongRequests   = new List<BetsModel>();

            var wrongRequest    = new BetsModel
            {
                message         = "unable to respond to incorrect request",
                status          = 3
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (data != null)
                {

                    var js = new JavaScriptSerializer();
                    string ipAddress = GetIpAddress();

                    List<BetsModel> getInfo = JsonConvert.DeserializeObject<List<BetsModel>>(js.Serialize(data));

                    var bet     = new BetsModel
                    {
                        message = requestFailed,
                        status  = -1
                    };

                    bets.Add(bet);

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_a_postSportCreate",       mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        foreach (var item in getInfo)
                        {
                            
                            cmd.Parameters.Add(new SqlParameter("@BetTypeID",           item.BetTypeID));
                            cmd.Parameters.Add(new SqlParameter("@TournamentID",        item.TournamentID));
                            cmd.Parameters.Add(new SqlParameter("@BetCommission",       item.BetCommission));
                            cmd.Parameters.Add(new SqlParameter("@BetName",             item.BetName));
                            cmd.Parameters.Add(new SqlParameter("@MinPlayableMatches",  item.MinPlayableMatches));
                            cmd.Parameters.Add(new SqlParameter("@MinAmount",           item.MinAmount));
                            cmd.Parameters.Add(new SqlParameter("@MaxAmount",           item.MaxAmount));
                            cmd.Parameters.Add(new SqlParameter("@BetEndDate",          item.BetEndDate));
                            cmd.Parameters.Add(new SqlParameter("@IsOpen",              (item.IsOpen ? 1 : 0)));
                            cmd.Parameters.Add(new SqlParameter("@BetDescription",      item.BetDescription));
                            cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                            cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       GetIpAddress()));
                            cmd.Parameters.Add(new SqlParameter("@_01",                 item._01));
                            cmd.Parameters.Add(new SqlParameter("@_02",                 item._02));
                            cmd.Parameters.Add(new SqlParameter("@_03",                 item._03));
                            cmd.Parameters.Add(new SqlParameter("@_04",                 item._04));
                            cmd.Parameters.Add(new SqlParameter("@_05",                 item._05));
                            cmd.Parameters.Add(new SqlParameter("@_06",                 item._06));
                            cmd.Parameters.Add(new SqlParameter("@_07",                 item._07));
                            cmd.Parameters.Add(new SqlParameter("@_08",                 item._08));
                            cmd.Parameters.Add(new SqlParameter("@_09",                 item._09));
                            cmd.Parameters.Add(new SqlParameter("@_10",                 item._10));
                            cmd.Parameters.Add(new SqlParameter("@_11",                 item._11));
                            cmd.Parameters.Add(new SqlParameter("@_12",                 item._12));
                            cmd.Parameters.Add(new SqlParameter("@_13",                 item._13));
                            cmd.Parameters.Add(new SqlParameter("@_14",                 item._14));
                            cmd.Parameters.Add(new SqlParameter("@_15",                 item._15));
                            cmd.Parameters.Add(new SqlParameter("@_16",                 item._16));
                            cmd.Parameters.Add(new SqlParameter("@_17",                 item._17));
                            cmd.Parameters.Add(new SqlParameter("@_18",                 item._18));
                            cmd.Parameters.Add(new SqlParameter("@_19",                 item._19));
                            cmd.Parameters.Add(new SqlParameter("@_20",                 item._20));
                            cmd.Parameters.Add(new SqlParameter("@_21",                 item._21));
                            cmd.Parameters.Add(new SqlParameter("@_22",                 item._22));
                            cmd.Parameters.Add(new SqlParameter("@_23",                 item._23));
                            cmd.Parameters.Add(new SqlParameter("@_24",                 item._24));
                            cmd.Parameters.Add(new SqlParameter("@_25",                 item._25));
                            cmd.Parameters.Add(new SqlParameter("@_26",                 item._26));

                            if (item.BetTypeID == 2)
                            {
                                cmd.Parameters.Add(new SqlParameter("@_27",             item._27));
                                cmd.Parameters.Add(new SqlParameter("@_28",             item._28));
                                cmd.Parameters.Add(new SqlParameter("@_29",             item._29));
                                cmd.Parameters.Add(new SqlParameter("@_30",             item._30));
                                cmd.Parameters.Add(new SqlParameter("@_31",             item._31));
                                cmd.Parameters.Add(new SqlParameter("@_32",             item._32));
                                cmd.Parameters.Add(new SqlParameter("@_33",             item._33));
                                cmd.Parameters.Add(new SqlParameter("@_34",             item._34));
                                cmd.Parameters.Add(new SqlParameter("@_35",             item._35));
                                cmd.Parameters.Add(new SqlParameter("@_36",             item._36));
                            }
                        }

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            bets.Clear();

                            int r = Convert.ToInt32(dr["Result"]);

                            if (r == 1)
                            {
                                bet         = new BetsModel
                                {
                                    message = "bet created successfully",
                                    status  = 1
                                };
                            }
                            else if (r == 2)
                            {
                                bet         = new BetsModel
                                {
                                    message = authenticationFailed,
                                    status  = 2
                                };
                            }                            
                        }

                        bets.Add(bet);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(bets);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// get competition counts
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void CompetitionCount(object token)
        {
            var competitions    = new List<ApiServiceModel>();

            try
            {
                var competition = new ApiServiceModel
                {
                    message     = authenticationFailed,
                    status      = -1
                };

                competitions.Add(competition);

                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();
                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                SqlCommand cmd  = new SqlCommand("usp_a_getCompetitionCount",   mainDatabase);
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (var item in getInfo)
                {
                    cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                }

                cmd.Parameters.Add(new SqlParameter("@LastIpAddress",           ipAddress));

                mainDatabase.Open();

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        competitions.Clear();

                        byte d = Convert.ToByte(dr["Result"]);

                        if (d == 1)
                        {
                            competition = new ApiServiceModel
                            {
                                ActiveFootballCompetitions      = Convert.ToInt64(dr["Football"]),
                                ActiveBasketballCompetitions    = Convert.ToInt64(dr["Basketball"]),
                                message                         = "request is successfully",
                                status                          = 1
                            };
                        }
                        else if (d == 2)
                        {
                            competition = new ApiServiceModel
                            {
                                message = requestFailed,
                                status  = 2
                            };
                        }

                        competitions.Add(competition);
                    }
                }

                dr.Close();
                mainDatabase.Close();

                developmentResponse(competitions);
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// SportActions
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="guid">guid</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void SportAction(object data)
        {
            var requests = new List<BetsModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<BetsModel> getInfo = JsonConvert.DeserializeObject<List<BetsModel>>(js.Serialize(data));

                var request = new BetsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                requests.Add(request);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postSportAction",   mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@BetGUID",         item.BetGUID));
                        cmd.Parameters.Add(new SqlParameter("@Action",          item.Action));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));                   

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            requests.Clear();
                            request     = new BetsModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            requests.Add(request);
                            break;
                        case 2:
                            requests.Clear();
                            request     = new BetsModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            requests.Add(request);
                            break;

                    }

                    mainDatabase.Close();

                    developmentResponse(requests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// api/v1/manage/sport/action/update (SportUpdate)
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void SportUpdate(object data)
        {
            var bets            = new List<BetsModel>();
            var wrongRequests   = new List<BetsModel>();

            var wrongRequest    = new BetsModel
            {
                message         = "unable to respond to incorrect request",
                status          = 3
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (data != null)
                {

                    var js = new JavaScriptSerializer();
                    string ipAddress = GetIpAddress();

                    List<BetsModel> getInfo = JsonConvert.DeserializeObject<List<BetsModel>>(js.Serialize(data));

                    var bet     = new BetsModel
                    {
                        message = requestFailed,
                        status  = -1
                    };

                    bets.Add(bet);

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_a_postSportUpdate",       mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        foreach (var item in getInfo)
                        {

                            cmd.Parameters.Add(new SqlParameter("@BetTypeID",           item.BetTypeID));
                            cmd.Parameters.Add(new SqlParameter("@TournamentID",        item.TournamentID));
                            cmd.Parameters.Add(new SqlParameter("@BetCommission",       item.BetCommission));
                            cmd.Parameters.Add(new SqlParameter("@BetName",             item.BetName));
                            cmd.Parameters.Add(new SqlParameter("@MinPlayableMatches",  item.MinPlayableMatches));
                            cmd.Parameters.Add(new SqlParameter("@MinAmount",           item.MinAmount));
                            cmd.Parameters.Add(new SqlParameter("@MaxAmount",           item.MaxAmount));
                            cmd.Parameters.Add(new SqlParameter("@BetEndDate",          item.BetEndDate));
                            cmd.Parameters.Add(new SqlParameter("@IsOpen",              (item.IsOpen ? 1 : 0)));
                            cmd.Parameters.Add(new SqlParameter("@BetDescription",      item.BetDescription));
                            cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                            cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       GetIpAddress()));
                            cmd.Parameters.Add(new SqlParameter("@_01",                 item._01));
                            cmd.Parameters.Add(new SqlParameter("@_02",                 item._02));
                            cmd.Parameters.Add(new SqlParameter("@_03",                 item._03));
                            cmd.Parameters.Add(new SqlParameter("@_04",                 item._04));
                            cmd.Parameters.Add(new SqlParameter("@_05",                 item._05));
                            cmd.Parameters.Add(new SqlParameter("@_06",                 item._06));
                            cmd.Parameters.Add(new SqlParameter("@_07",                 item._07));
                            cmd.Parameters.Add(new SqlParameter("@_08",                 item._08));
                            cmd.Parameters.Add(new SqlParameter("@_09",                 item._09));
                            cmd.Parameters.Add(new SqlParameter("@_10",                 item._10));
                            cmd.Parameters.Add(new SqlParameter("@_11",                 item._11));
                            cmd.Parameters.Add(new SqlParameter("@_12",                 item._12));
                            cmd.Parameters.Add(new SqlParameter("@_13",                 item._13));
                            cmd.Parameters.Add(new SqlParameter("@_14",                 item._14));
                            cmd.Parameters.Add(new SqlParameter("@_15",                 item._15));
                            cmd.Parameters.Add(new SqlParameter("@_16",                 item._16));
                            cmd.Parameters.Add(new SqlParameter("@_17",                 item._17));
                            cmd.Parameters.Add(new SqlParameter("@_18",                 item._18));
                            cmd.Parameters.Add(new SqlParameter("@_19",                 item._19));
                            cmd.Parameters.Add(new SqlParameter("@_20",                 item._20));
                            cmd.Parameters.Add(new SqlParameter("@_21",                 item._21));
                            cmd.Parameters.Add(new SqlParameter("@_22",                 item._22));
                            cmd.Parameters.Add(new SqlParameter("@_23",                 item._23));
                            cmd.Parameters.Add(new SqlParameter("@_24",                 item._24));
                            cmd.Parameters.Add(new SqlParameter("@_25",                 item._25));
                            cmd.Parameters.Add(new SqlParameter("@_26",                 item._26));
                            cmd.Parameters.Add(new SqlParameter("@BetGUID",             item.BetGUID));

                            if (item.BetTypeID == 2)
                            {
                                cmd.Parameters.Add(new SqlParameter("@_27",             item._27));
                                cmd.Parameters.Add(new SqlParameter("@_28",             item._28));
                                cmd.Parameters.Add(new SqlParameter("@_29",             item._29));
                                cmd.Parameters.Add(new SqlParameter("@_30",             item._30));
                                cmd.Parameters.Add(new SqlParameter("@_31",             item._31));
                                cmd.Parameters.Add(new SqlParameter("@_32",             item._32));
                                cmd.Parameters.Add(new SqlParameter("@_33",             item._33));
                                cmd.Parameters.Add(new SqlParameter("@_34",             item._34));
                                cmd.Parameters.Add(new SqlParameter("@_35",             item._35));
                                cmd.Parameters.Add(new SqlParameter("@_36",             item._36));
                            }
                        }

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            bets.Clear();

                            int r = Convert.ToInt32(dr["Result"]);

                            if (r == 1)
                            {
                                bet         = new BetsModel
                                {
                                    message = "bet update successfully",
                                    status  = 1
                                };
                            }
                            else if (r == 2)
                            {
                                bet         = new BetsModel
                                {
                                    message = authenticationFailed,
                                    status  = 2
                                };
                            }
                        }

                        bets.Add(bet);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(bets);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// api/v1/manage/sport/action/bet (getBet)
        /// </summary>
        /// <param name="betTypeID">Bet type id, 1 for football, 2 for basketball</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void Sport(object data)
        {
            try
            {
                bool clearCheck = true;
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<BetsModel> getInfo = JsonConvert.DeserializeObject<List<BetsModel>>(js.Serialize(data));

                var bets    = new List<BetsModel>();

                var bet1    = new BetsModel
                {
                    message = "no bet found",
                    status  = -1
                };

                bets.Add(bet1);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_getSport",      mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@BetGUID",     item.BetGUID));
                        cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) bets.Clear();
                        int d = Convert.ToInt32(dr["Result"]);
                        int betTypeID = Convert.ToByte(dr["BetTypeID"]);

                        if (d == 1)
                        {
                            if (betTypeID == 1)
                            {
                                // football
                                bet1 = new BetsModel
                                {
                                    BetTypeID           = Convert.ToByte(dr["BetTypeID"]),
                                    TournamentID        = Convert.ToInt16(dr["TournamentID"]),
                                    BetName             = dr["BetName"].ToString(),
                                    BetCommission       = Convert.ToDecimal(dr["BetCommission"]),
                                    MinPlayableMatches  = Convert.ToByte(dr["MinPlayableMatches"]),
                                    MinAmount           = Convert.ToDecimal(dr["MinAmount"]),
                                    MaxAmount           = Convert.ToDecimal(dr["MaxAmount"]),
                                    BetDescription      = dr["BetDescription"].ToString(),
                                    BetEndDate          = Convert.ToDateTime(dr["BetEndDate"]),
                                    IsOpen              = Convert.ToBoolean(dr["IsOpen"]),
                                    _01 = Convert.ToDecimal(dr["_01"]).ToString("0.00").Replace(",", "."),
                                    _02 = Convert.ToDecimal(dr["_02"]).ToString("0.00").Replace(",", "."),
                                    _03 = Convert.ToDecimal(dr["_03"]).ToString("0.00").Replace(",", "."),
                                    _04 = Convert.ToDecimal(dr["_04"]).ToString("0.00").Replace(",", "."),
                                    _05 = Convert.ToDecimal(dr["_05"]).ToString("0.00").Replace(",", "."),
                                    _06 = Convert.ToDecimal(dr["_06"]).ToString("0.00").Replace(",", "."),
                                    _07 = Convert.ToDecimal(dr["_07"]).ToString("0.00").Replace(",", "."),
                                    _08 = Convert.ToDecimal(dr["_08"]).ToString("0.00").Replace(",", "."),
                                    _09 = Convert.ToDecimal(dr["_09"]).ToString("0.00").Replace(",", "."),
                                    _10 = Convert.ToDecimal(dr["_10"]).ToString("0.00").Replace(",", "."),
                                    _11 = Convert.ToDecimal(dr["_11"]).ToString("0.00").Replace(",", "."),
                                    _12 = Convert.ToDecimal(dr["_12"]).ToString("0.00").Replace(",", "."),
                                    _13 = Convert.ToDecimal(dr["_13"]).ToString("0.00").Replace(",", "."),
                                    _14 = Convert.ToDecimal(dr["_14"]).ToString("0.00").Replace(",", "."),
                                    _15 = Convert.ToDecimal(dr["_15"]).ToString("0.00").Replace(",", "."),
                                    _16 = Convert.ToDecimal(dr["_16"]).ToString("0.00").Replace(",", "."),
                                    _17 = Convert.ToDecimal(dr["_17"]).ToString("0.00").Replace(",", "."),
                                    _18 = Convert.ToDecimal(dr["_18"]).ToString("0.00").Replace(",", "."),
                                    _19 = Convert.ToDecimal(dr["_19"]).ToString("0.00").Replace(",", "."),
                                    _20 = Convert.ToDecimal(dr["_20"]).ToString("0.00").Replace(",", "."),
                                    _21 = Convert.ToDecimal(dr["_21"]).ToString("0.00").Replace(",", "."),
                                    _22 = Convert.ToDecimal(dr["_22"]).ToString("0.00").Replace(",", "."),
                                    _23 = Convert.ToDecimal(dr["_23"]).ToString("0.00").Replace(",", "."),
                                    _24 = Convert.ToDecimal(dr["_24"]).ToString("0.00").Replace(",", "."),
                                    _25 = Convert.ToDecimal(dr["_25"]).ToString("0.00").Replace(",", "."),
                                    _26 = Convert.ToDecimal(dr["_26"]).ToString("0.00").Replace(",", "."),
                                    message = "request is successfully",
                                    status  = 1
                                };
                            }
                            else if (betTypeID == 2)
                            {
                                // basketball
                                bet1 = new BetsModel
                                {
                                    BetTypeID           = Convert.ToByte(dr["BetTypeID"]),
                                    TournamentID        = Convert.ToInt16(dr["TournamentID"]),
                                    BetName             = dr["BetName"].ToString(),
                                    BetCommission       = Convert.ToDecimal(dr["BetCommission"]),
                                    MinPlayableMatches  = Convert.ToByte(dr["MinPlayableMatches"]),
                                    MinAmount           = Convert.ToDecimal(dr["MinAmount"]),
                                    MaxAmount           = Convert.ToDecimal(dr["MaxAmount"]),
                                    BetDescription      = dr["BetDescription"].ToString(),
                                    BetEndDate          = Convert.ToDateTime(dr["BetEndDate"]),
                                    IsOpen              = Convert.ToBoolean(dr["IsOpen"]),
                                    _01 = Convert.ToDecimal(dr["_01"]).ToString("0.00").Replace(",", "."),
                                    _02 = Convert.ToDecimal(dr["_02"]).ToString("0.00").Replace(",", "."),
                                    _03 = Convert.ToDecimal(dr["_03"]).ToString("0.00").Replace(",", "."),
                                    _04 = Convert.ToDecimal(dr["_04"]).ToString("0.00").Replace(",", "."),
                                    _05 = Convert.ToDecimal(dr["_05"]).ToString("0.00").Replace(",", "."),
                                    _06 = Convert.ToDecimal(dr["_06"]).ToString("0.00").Replace(",", "."),
                                    _07 = Convert.ToDecimal(dr["_07"]).ToString("0.00").Replace(",", "."),
                                    _08 = Convert.ToDecimal(dr["_08"]).ToString("0.00").Replace(",", "."),
                                    _09 = Convert.ToDecimal(dr["_09"]).ToString("0.00").Replace(",", "."),
                                    _10 = Convert.ToDecimal(dr["_10"]).ToString("0.00").Replace(",", "."),
                                    _11 = Convert.ToDecimal(dr["_11"]).ToString("0.00").Replace(",", "."),
                                    _12 = Convert.ToDecimal(dr["_12"]).ToString("0.00").Replace(",", "."),
                                    _13 = Convert.ToDecimal(dr["_13"]).ToString("0.00").Replace(",", "."),
                                    _14 = Convert.ToDecimal(dr["_14"]).ToString("0.00").Replace(",", "."),
                                    _15 = Convert.ToDecimal(dr["_15"]).ToString("0.00").Replace(",", "."),
                                    _16 = Convert.ToDecimal(dr["_16"]).ToString("0.00").Replace(",", "."),
                                    _17 = Convert.ToDecimal(dr["_17"]).ToString("0.00").Replace(",", "."),
                                    _18 = Convert.ToDecimal(dr["_18"]).ToString("0.00").Replace(",", "."),
                                    _19 = Convert.ToDecimal(dr["_19"]).ToString("0.00").Replace(",", "."),
                                    _20 = Convert.ToDecimal(dr["_20"]).ToString("0.00").Replace(",", "."),
                                    _21 = Convert.ToDecimal(dr["_21"]).ToString("0.00").Replace(",", "."),
                                    _22 = Convert.ToDecimal(dr["_22"]).ToString("0.00").Replace(",", "."),
                                    _23 = Convert.ToDecimal(dr["_23"]).ToString("0.00").Replace(",", "."),
                                    _24 = Convert.ToDecimal(dr["_24"]).ToString("0.00").Replace(",", "."),
                                    _25 = Convert.ToDecimal(dr["_25"]).ToString("0.00").Replace(",", "."),
                                    _26 = Convert.ToDecimal(dr["_26"]).ToString("0.00").Replace(",", "."),
                                    _27 = Convert.ToDecimal(dr["_27"]).ToString("0.00").Replace(",", "."),
                                    _28 = Convert.ToDecimal(dr["_28"]).ToString("0.00").Replace(",", "."),
                                    _29 = Convert.ToDecimal(dr["_29"]).ToString("0.00").Replace(",", "."),
                                    _30 = Convert.ToDecimal(dr["_30"]).ToString("0.00").Replace(",", "."),
                                    _31 = Convert.ToDecimal(dr["_31"]).ToString("0.00").Replace(",", "."),
                                    _32 = Convert.ToDecimal(dr["_32"]).ToString("0.00").Replace(",", "."),
                                    _33 = Convert.ToDecimal(dr["_33"]).ToString("0.00").Replace(",", "."),
                                    _34 = Convert.ToDecimal(dr["_34"]).ToString("0.00").Replace(",", "."),
                                    _35 = Convert.ToDecimal(dr["_35"]).ToString("0.00").Replace(",", "."),
                                    _36 = Convert.ToDecimal(dr["_36"]).ToString("0.00").Replace(",", "."),
                                    message = "request is successfully",
                                    status  = 1
                                };
                            }
                            
                            bets.Add(bet1);
                        }
                        else if (d == 3)
                        {
                            bet1        = new BetsModel
                            {
                                message = "invalid uuid address request",
                                status  = 3
                            };
                            bets.Add(bet1);
                        }
                        else
                        {
                            bet1        = new BetsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            bets.Add(bet1);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(bets);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// api/v1/manage/deposits (Deposits)
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Deposits(object data)
        {
            try
            {
                bool clearCheck = true;
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<DepositRequestsModel> getInfo = JsonConvert.DeserializeObject<List<DepositRequestsModel>>(js.Serialize(data));

                var deposits    = new List<DepositRequestsModel>();

                var deposit     = new DepositRequestsModel
                {
                    message     = "no deposit found",
                    status      = -1
                };

                deposits.Add(deposit);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postDeposits",      mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@TradingStatus",   item.TradingStatus));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) deposits.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            deposit                         = new DepositRequestsModel
                            {
                                ID                          = Convert.ToInt32(dr["ID"]),
                                TradingStatus               = Convert.ToByte(dr["TradingStatus"]),
                                TradingIBAN                 = dr["TradingIBAN"].ToString(),
                                TradingAmountStr            = Convert.ToDecimal(dr["TradingAmount"]).ToString("0.00").Replace(",", "."),
                                TradingSuccessfulAmountStr  = Convert.ToDecimal(dr["TradingSuccessfulAmount"]).ToString("0.00").Replace(",", "."),
                                TradingHour                 = dr["TradingHour"].ToString(),
                                TradingImagePath            = dr["TradingImagePath"].ToString(),
                                TradingGUID                 = dr["TradingGUID"].ToString(),
                                TradingRequestDate          = Convert.ToDateTime(dr["TradingRequestDate"]),
                                LastUpdateDate              = Convert.ToDateTime(dr["LastUpdateDate"]),
                                UserName                    = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                Balance                     = Convert.ToDecimal(dr["Balance"]),
                                message                     = "request is successfully",
                                status                      = 1
                            };

                            deposits.Add(deposit);
                        }
                        else
                        {
                            deposit     = new DepositRequestsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            deposits.Add(deposit);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(deposits);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// DepositAction
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="guid">guid</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void DepositAction(object data)
        {
            var deposits = new List<DepositRequestsModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<DepositRequestsModel> getInfo = JsonConvert.DeserializeObject<List<DepositRequestsModel>>(js.Serialize(data));

                var deposit = new DepositRequestsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                deposits.Add(deposit);

                using (mainDatabase)
                {
                    SqlCommand cmd = new SqlCommand("usp_a_postDepositAction",      mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        
                        if (item.ManuelAmount > 0) 
                            cmd.Parameters.Add(new SqlParameter("@ManuelAmount",    item.ManuelAmount));

                        cmd.Parameters.Add(new SqlParameter("@TradingGUID",         item.TradingGUID));
                        cmd.Parameters.Add(new SqlParameter("@Action",              item.Action));
                        cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",           ipAddress));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            deposits.Clear();
                            deposit     = new DepositRequestsModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            deposits.Add(deposit);
                            break;
                        case 2:
                            deposits.Clear();
                            deposit     = new DepositRequestsModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            deposits.Add(deposit);
                            break;

                    }

                    mainDatabase.Close();

                    developmentResponse(deposits);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// api/v1/manage/withdraws (Withdraws)
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Withdraws(object data)
        {
            try
            {
                bool clearCheck = true;
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<DepositRequestsModel> getInfo = JsonConvert.DeserializeObject<List<DepositRequestsModel>>(js.Serialize(data));

                var deposits    = new List<DepositRequestsModel>();

                var deposit     = new DepositRequestsModel
                {
                    message     = "no withdraw found",
                    status      = -1
                };

                deposits.Add(deposit);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postWithdraws",      mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@TradingStatus",   item.TradingStatus));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) deposits.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            deposit                         = new DepositRequestsModel
                            {
                                ID                          = Convert.ToInt32(dr["ID"]),
                                TradingStatus               = Convert.ToByte(dr["TradingStatus"]),
                                TradingIBAN                 = dr["TradingIBAN"].ToString(),
                                TradingAmount               = Convert.ToDecimal(dr["TradingAmount"]),
                                TradingAmountStr            = Convert.ToDecimal(dr["TradingAmount"]).ToString("0.00").Replace(",", "."),
                                TradingSuccessfulAmountStr  = Convert.ToDecimal(dr["TradingSuccessfulAmount"]).ToString("0.00").Replace(",", "."),
                                TradingGUID                 = dr["TradingGUID"].ToString(),
                                TradingRequestDate          = Convert.ToDateTime(dr["TradingRequestDate"]),
                                LastUpdateDate              = Convert.ToDateTime(dr["LastUpdateDate"]),
                                UserName                    = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                Balance                     = Convert.ToDecimal(dr["Balance"]),
                                message                     = "request is successfully",
                                status                      = 1
                            };

                            deposits.Add(deposit);
                        }
                        else
                        {
                            deposit     = new DepositRequestsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            deposits.Add(deposit);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(deposits);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// WithdrawAction
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="guid">guid</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void WithdrawAction(object data)
        {
            var deposits = new List<DepositRequestsModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<DepositRequestsModel> getInfo = JsonConvert.DeserializeObject<List<DepositRequestsModel>>(js.Serialize(data));

                var deposit = new DepositRequestsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                deposits.Add(deposit);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postWithdrawAction",    mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {

                        if (item.ManuelAmount > 0) 
                            cmd.Parameters.Add(new SqlParameter("@ManuelAmount",    item.ManuelAmount));

                        cmd.Parameters.Add(new SqlParameter("@TradingGUID",         item.TradingGUID));
                        cmd.Parameters.Add(new SqlParameter("@Action",              item.Action));
                        cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",           ipAddress));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            deposits.Clear();
                            deposit     = new DepositRequestsModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            deposits.Add(deposit);
                            break;
                        case 2:
                            deposits.Clear();
                            deposit     = new DepositRequestsModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            deposits.Add(deposit);
                            break;
                    }

                    mainDatabase.Close();

                    developmentResponse(deposits);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// FinalizeBet
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void FinalizeBet(object data)
        {
            var bets = new List<BetsModel>();

            try
            {
                var bet     = new BetsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                bets.Add(bet);

                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();
                List<BetsModel> getInfo = JsonConvert.DeserializeObject<List<BetsModel>>(js.Serialize(data));

                SqlCommand cmd  = new SqlCommand("usp_a_getFinalizeBet",mainDatabase);
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (var item in getInfo)
                {
                    cmd.Parameters.Add(new SqlParameter("@BetGUID",     item.BetGUID));
                    cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                }

                cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                mainDatabase.Open();

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        bets.Clear();

                        byte d = Convert.ToByte(dr["Result"]);

                        if (d == 1)
                        {
                            bet         = new BetsModel
                            {
                                BetCode = dr["BetCode"].ToString(),
                                BetName = dr["BetName"].ToString(),
                                message = "request is successfully",
                                status  = 1
                            };
                        }
                        else if (d == 2)
                        {
                            bet         = new BetsModel
                            {
                                message = requestFailed,
                                status  = 2
                            };
                        }
                        else if (d == 3)
                        {
                            bet         = new BetsModel
                            {
                                message = "invalid uuid address request",
                                status  = 3
                            };
                        }
                        

                        bets.Add(bet);
                    }
                }

                dr.Close();
                mainDatabase.Close();

                developmentResponse(bets);
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// FinalizeBetScore
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void FinalizeBetScore(object data)
        {
            bool check = true;

            string betGUID = "";
            Int16 teamOneHalfTimeScore = 0;
            Int16 teamOneFullTimeScore = 0;
            Int16 teamTwoHalfTimeScore = 0;
            Int16 teamTwoFullTimeScore = 0;

            var bets = new List<BetsModel>();
            var wrongRequests = new List<BetsModel>();

            var wrongRequest = new BetsModel
            {
                message = "unable to respond to incorrect request",
                status  = 3
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (data != null)
                {

                    var js = new JavaScriptSerializer();
                    string ipAddress = GetIpAddress();

                    List<BetsModel> getInfo = JsonConvert.DeserializeObject<List<BetsModel>>(js.Serialize(data));

                    var bet = new BetsModel
                    {
                        message = requestFailed,
                        status  = -1
                    };

                    bets.Add(bet);

                    using (mainDatabase)
                    {
                        SqlCommand cmd1     = new SqlCommand("usp_a_postFinalizeScore", mainDatabase);
                        cmd1.CommandType    = CommandType.StoredProcedure;

                        foreach (var item in getInfo)
                        {
                            betGUID                 = item.BetGUID;
                            teamOneHalfTimeScore    = item.TeamOneHalfTimeScore;
                            teamOneFullTimeScore    = item.TeamOneFullTimeScore;
                            teamTwoHalfTimeScore    = item.TeamTwoHalfTimeScore;
                            teamTwoFullTimeScore    = item.TeamTwoFullTimeScore;

                            cmd1.Parameters.Add(new SqlParameter("@BetGUID",        item.BetGUID));
                            cmd1.Parameters.Add(new SqlParameter("@Token",          item.Token));
                            cmd1.Parameters.Add(new SqlParameter("@LastIpAddress",  GetIpAddress()));
                        }

                        mainDatabase.Open();

                        var dr1 = cmd1.ExecuteReader();

                        while (dr1.Read())
                        {
                            bets.Clear();

                            int r = Convert.ToInt32(dr1["Result"]);

                            if (r == 1)
                            {
                                long couponDetailID =   FinalizeOdds(Convert.ToByte(dr1["BetTypeID"]),
                                                        dr1["SelectedBetOption"].ToString(),
                                                        Convert.ToInt64(dr1["CouponDetailID"]),
                                                        teamOneHalfTimeScore,
                                                        teamOneFullTimeScore,
                                                        teamTwoHalfTimeScore,
                                                        teamTwoFullTimeScore);

                                byte couponDetailStatus = 2;

                                if (couponDetailID > 0)
                                {
                                    couponDetailStatus = 1;
                                }

                                using (mainDatabaseNested)
                                {
                                    SqlCommand cmd2 = new SqlCommand("usp_a_postFinalizeCouponDetail",  mainDatabaseNested);
                                    cmd2.CommandType = CommandType.StoredProcedure;

                                    cmd2.Parameters.Add(new SqlParameter("@CouponDetailID_Fail",        Convert.ToInt64(dr1["CouponDetailID"])));
                                    cmd2.Parameters.Add(new SqlParameter("@AccountID",                  Convert.ToInt32(dr1["AccountID"])));
                                    cmd2.Parameters.Add(new SqlParameter("@BetGUID",                    betGUID));
                                    cmd2.Parameters.Add(new SqlParameter("@TeamOneHalfTimeScore",       teamOneHalfTimeScore));
                                    cmd2.Parameters.Add(new SqlParameter("@TeamOneFullTimeScore",       teamOneFullTimeScore));
                                    cmd2.Parameters.Add(new SqlParameter("@TeamTwoHalfTimeScore",       teamTwoHalfTimeScore));
                                    cmd2.Parameters.Add(new SqlParameter("@TeamTwoFullTimeScore",       teamTwoFullTimeScore));

                                    cmd2.Parameters.Add(new SqlParameter("@CouponID",                   Convert.ToInt64(dr1["CouponID"])));
                                    cmd2.Parameters.Add(new SqlParameter("@CouponDetailID",             couponDetailID));
                                    cmd2.Parameters.Add(new SqlParameter("@CouponDetailStatus",         couponDetailStatus));

                                    mainDatabaseNested.Open();

                                    cmd2.ExecuteScalar();

                                    mainDatabaseNested.Close();
                                }

                                if (check)
                                {
                                    bet         = new BetsModel
                                    {
                                        message = "bet finalize scores successfully",
                                        status  = 1
                                    };
                                }
                                check = false;
                            }
                            else if (r == 2)
                            {
                                if (check)
                                {
                                    bet         = new BetsModel
                                    {
                                        message = authenticationFailed,
                                        status  = 2
                                    };
                                }
                                check = false;
                            }
                        }

                        bets.Add(bet);

                        dr1.Close();
                        mainDatabaseNested.Close();
                        mainDatabase.Close();

                        developmentResponse(bets);
                    }
                }
                else
                {
                    mainDatabaseNested.Close();
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabaseNested.Close();
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// FinalizeOdds
        /// </summary>
        /// <param name="betTypeID">betTypeID</param>
        /// <param name="selectedBetOption">selectedBetOption</param>
        /// <param name="couponDetailID">couponDetailID</param>
        /// <param name="teamOneHalfTimeScore">teamOneHalfTimeScore</param>
        /// <param name="teamOneFullTimeScore">teamOneFullTimeScore</param>
        /// <param name="teamTwoHalfTimeScore">teamTwoHalfTimeScore</param>
        /// <param name="teamTwoFullTimeScore">teamTwoFullTimeScore</param>
        /// <returns></returns>
        public long FinalizeOdds(   byte    betTypeID, 
                                    string  selectedBetOption, 
                                    long    couponDetailID, 
                                    Int16   teamOneHalfTimeScore, 
                                    Int16   teamOneFullTimeScore, 
                                    Int16   teamTwoHalfTimeScore, 
                                    Int16   teamTwoFullTimeScore)
        {
            long r = 0;

            switch(betTypeID)
            {
                case 1:
                    switch (selectedBetOption)
                    {
                        case "_01":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_02":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) == (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_03":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) < (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_04":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) >= (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_05":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore) ||
                                (teamOneHalfTimeScore + teamOneFullTimeScore) < (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_06":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) <= (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_07":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 0) r = couponDetailID;
                            break;
                        case "_08":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 1) r = couponDetailID;
                            break;
                        case "_09":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 2) r = couponDetailID;
                            break;
                        case "_10":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 3) r = couponDetailID;
                            break;
                        case "_11":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 4) r = couponDetailID;
                            break;
                        case "_12":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 5) r = couponDetailID;
                            break;
                        case "_13":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 1) r = couponDetailID;
                            break;
                        case "_14":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 2) r = couponDetailID;
                            break;
                        case "_15":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 3) r = couponDetailID;
                            break;
                        case "_16":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 4) r = couponDetailID;
                            break;
                        case "_17":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 5) r = couponDetailID;
                            break;
                        case "_18":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 6) r = couponDetailID;
                            break;
                        case "_19":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) > 0 &&
                                (teamTwoHalfTimeScore + teamTwoFullTimeScore) > 0) r = couponDetailID;
                            break;
                        case "_20":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) == 0 ||
                                (teamTwoHalfTimeScore + teamTwoFullTimeScore) == 0) r = couponDetailID;
                            break;
                        case "_21":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) % 2 == 1) r = couponDetailID;
                            break;
                        case "_22":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) % 2 == 0) r = couponDetailID;
                            break;
                        case "_23":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) <= 1) r = couponDetailID;
                            break;
                        case "_24":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) >= 2 &&
                                (teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) <= 3) r = couponDetailID;
                            break;
                        case "_25":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) >= 4 &&
                                (teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) <= 5) r = couponDetailID;
                            break;
                        case "_26":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 6) r = couponDetailID;
                            break;
                    }
                    break;
                case 2:
                    switch (selectedBetOption)
                    {
                        case "_01":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_02":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore) < (teamTwoHalfTimeScore + teamTwoFullTimeScore)) r = couponDetailID;
                            break;
                        case "_03":
                            if ((teamOneHalfTimeScore > teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_04":
                            if ((teamOneHalfTimeScore > teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) == (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_05":
                            if ((teamOneHalfTimeScore > teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) < (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_06":
                            if ((teamOneHalfTimeScore == teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_07":
                            if ((teamOneHalfTimeScore == teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) == (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_08":
                            if ((teamOneHalfTimeScore == teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) < (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_09":
                            if ((teamOneHalfTimeScore < teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_10":
                            if ((teamOneHalfTimeScore < teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) == (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_11":
                            if ((teamOneHalfTimeScore < teamTwoHalfTimeScore) &&
                                ((teamOneHalfTimeScore + teamOneFullTimeScore) > (teamTwoHalfTimeScore + teamTwoFullTimeScore))) r = couponDetailID;
                            break;
                        case "_12":
                            if (teamOneHalfTimeScore > teamTwoHalfTimeScore) r = couponDetailID;
                            break;
                        case "_13":
                            if (teamOneHalfTimeScore == teamTwoHalfTimeScore) r = couponDetailID;
                            break;
                        case "_14":
                            if (teamOneHalfTimeScore < teamTwoHalfTimeScore) r = couponDetailID;
                            break;
                        case "_15":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 160) r = couponDetailID;
                            break;
                        case "_16":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 161) r = couponDetailID;
                            break;
                        case "_17":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 162) r = couponDetailID;
                            break;
                        case "_18":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 163) r = couponDetailID;
                            break;
                        case "_19":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 164) r = couponDetailID;
                            break;
                        case "_20":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 165) r = couponDetailID;
                            break;
                        case "_21":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 166) r = couponDetailID;
                            break;
                        case "_22":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 167) r = couponDetailID;
                            break;
                        case "_23":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 168) r = couponDetailID;
                            break;
                        case "_24":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 169) r = couponDetailID;
                            break;
                        case "_25":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) < 170) r = couponDetailID;
                            break;
                        case "_26":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 159) r = couponDetailID;
                            break;
                        case "_27":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 160) r = couponDetailID;
                            break;
                        case "_28":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 161) r = couponDetailID;
                            break;
                        case "_29":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 162) r = couponDetailID;
                            break;
                        case "_30":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 163) r = couponDetailID;
                            break;
                        case "_31":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 164) r = couponDetailID;
                            break;
                        case "_32":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 165) r = couponDetailID;
                            break;
                        case "_33":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 166) r = couponDetailID;
                            break;
                        case "_34":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 167) r = couponDetailID;
                            break;
                        case "_35":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 168) r = couponDetailID;
                            break;
                        case "_36":
                            if ((teamOneHalfTimeScore + teamOneFullTimeScore + teamTwoHalfTimeScore + teamTwoFullTimeScore) > 169) r = couponDetailID;
                            break;
                    }
                    break;
            }

            return r;
        }

        /// <summary>
        /// api/v1/manage/coupons (Coupons)
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Coupons(object data)
        {
            try
            {
                bool clearCheck = true;
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<CouponsModel> getInfo = JsonConvert.DeserializeObject<List<CouponsModel>>(js.Serialize(data));

                var coupons = new List<CouponsModel>();

                var coupon  = new CouponsModel
                {
                    message = "no coupon found",
                    status  = -1
                };

                coupons.Add(coupon);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postCoupons",       mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@CouponStatus",    item.CouponStatus));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) coupons.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            coupon                      = new CouponsModel
                            {
                                ID                      = Convert.ToInt64(dr["ID"]),
                                UserName                = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                Balance                 = Convert.ToDecimal(dr["Balance"]),
                                BetAmount               = Convert.ToInt64(dr["BetAmount"]),
                                WinningRateStr          = Convert.ToDecimal(dr["WinningRate"]).ToString("0.00").Replace(",", "."),
                                AmountPlayedStr         = Convert.ToDecimal(dr["AmountPlayed"]).ToString("0.00").Replace(",", "."),
                                EarnedAmountWithTaxStr  = Convert.ToDecimal(dr["EarnedAmountWithTax"]).ToString("0.00").Replace(",", "."),
                                CreatedDate             = Convert.ToDateTime(dr["CreatedDate"]),
                                LastUpdateDate          = Convert.ToDateTime(dr["LastUpdateDate"]),
                                CouponStatus            = Convert.ToByte(dr["CouponStatus"]),
                                CouponGUID              = dr["CouponGUID"].ToString(),
                                message                 = "request is successfully",
                                status                  = 1
                            };

                            coupons.Add(coupon);
                        }
                        else
                        {
                            coupon      = new CouponsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            coupons.Add(coupon);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(coupons);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// CouponAction
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="guid">guid</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void CouponAction(object data)
        {
            var coupons = new List<CouponsModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<CouponsModel> getInfo = JsonConvert.DeserializeObject<List<CouponsModel>>(js.Serialize(data));

                var coupon  = new CouponsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                coupons.Add(coupon);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postCouponAction",  mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {

                        cmd.Parameters.Add(new SqlParameter("@CouponGUID",      item.CouponGUID));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            coupons.Clear();
                            coupon      = new CouponsModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            coupons.Add(coupon);
                            break;
                        case 2:
                            coupons.Clear();
                            coupon      = new CouponsModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            coupons.Add(coupon);
                            break;
                    }

                    mainDatabase.Close();

                    developmentResponse(coupons);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// Accounts
        /// </summary>
        /// <param name="token">token</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Accounts(object token)
        {
            try
            {
                bool clearCheck = true;
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var accounts = new List<AccountsModel>();

                var account = new AccountsModel
                {
                    message = "no account found",
                    status  = -1
                };

                accounts.Add(account);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postAccounts",  mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) accounts.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            account             = new AccountsModel
                            {
                                ID              = Convert.ToInt32(dr["ID"]),
                                UserName        = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                EMail           = Aes(Operation.Decrypt, dr["EMail"].ToString()),
                                AccountRole     = Convert.ToByte(dr["AccountRole"]),
                                Balance         = Convert.ToDecimal(dr["Balance"]),
                                IsLoggedIn      = Convert.ToBoolean(dr["IsLoggedIn"]),
                                RegisteredDate  = Convert.ToDateTime(dr["RegisteredDate"]),
                                AccountGUID     = dr["AccountGUID"].ToString(),
                                message         = "request is successfully",
                                status          = 1
                            };
                            accounts.Add(account);
                        }
                        else
                        {
                            account     = new AccountsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            accounts.Add(account);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(accounts);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// AccountAction
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void AccountAction(object data)
        {
            var accounts = new List<AccountsModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<AccountsModel> getInfo = JsonConvert.DeserializeObject<List<AccountsModel>>(js.Serialize(data));

                var account = new AccountsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                accounts.Add(account);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postAccountAction", mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@AccountGUID",     item.AccountGUID));
                        cmd.Parameters.Add(new SqlParameter("@Action",          item.Action));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            accounts.Clear();
                            account     = new AccountsModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            accounts.Add(account);
                            break;
                        case 2:
                            accounts.Clear();
                            account     = new AccountsModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            accounts.Add(account);
                            break;
                    }

                    mainDatabase.Close();

                    developmentResponse(accounts);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// Account
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void Account(object data)
        {
            try
            {
                bool clearCheck     = true;
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();

                List<AccountsModel> getInfo = JsonConvert.DeserializeObject<List<AccountsModel>>(js.Serialize(data));

                var accounts    = new List<AccountsModel>();

                var account     = new AccountsModel
                {
                    message     = "no account found",
                    status      = -1
                };

                accounts.Add(account);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_getAccount",        mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@AccountGUID",     item.AccountGUID));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) accounts.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            account             = new AccountsModel
                            {
                                UserName        = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                EMail           = Aes(Operation.Decrypt, dr["EMail"].ToString()),
                                AccountRole     = Convert.ToByte(dr["AccountRole"]),
                                Balance         = Convert.ToDecimal(dr["Balance"]),
                                RegisteredDate  = Convert.ToDateTime(dr["RegisteredDate"]),
                                AccountGUID     = dr["AccountGUID"].ToString(),
                                message         = "request is successfully",
                                status          = 1
                            };

                            accounts.Add(account);
                        }
                        else if (d == 3)
                        {
                            account     = new AccountsModel
                            {
                                message = "invalid uuid address request",
                                status  = 3
                            };
                            accounts.Add(account);
                        }
                        else
                        {
                            account     = new AccountsModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            accounts.Add(account);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(accounts);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// AccountUpdate
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void AccountUpdate(object data)
        {
            var accounts        = new List<AccountsModel>();
            var wrongRequests   = new List<AccountsModel>();

            var wrongRequest    = new AccountsModel
            {
                message         = "unable to respond to incorrect request",
                status          = 3
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (data != null)
                {

                    var js              = new JavaScriptSerializer();
                    string ipAddress    = GetIpAddress();

                    List<AccountsModel> getInfo = JsonConvert.DeserializeObject<List<AccountsModel>>(js.Serialize(data));

                    var account = new AccountsModel
                    {
                        message = requestFailed,
                        status  = -1
                    };

                    accounts.Add(account);

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_a_postAccountUpdate",     mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        foreach (var item in getInfo)
                        {
                            cmd.Parameters.Add(new SqlParameter("@BalanceAction",       item.Action));
                            cmd.Parameters.Add(new SqlParameter("@Balance",             item.Balance));

                            if (item.HashPassword.Length >= 6 && item.HashPassword.Length <= 32) 
                                cmd.Parameters.Add(new SqlParameter("@HashPassword",    Aes(Operation.Encrypt, item.HashPassword)));

                            cmd.Parameters.Add(new SqlParameter("@AccountRole",         item.AccountRole));
                            cmd.Parameters.Add(new SqlParameter("@AccountGUID",         item.AccountGUID));
                            cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                            cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       GetIpAddress()));
                        }

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            accounts.Clear();

                            int r = Convert.ToInt32(dr["Result"]);

                            if (r == 1)
                            {
                                account     = new AccountsModel
                                {
                                    message = "account update successfully",
                                    status  = 1
                                };
                            }
                            else if (r == 2)
                            {
                                account     = new AccountsModel
                                {
                                    message = authenticationFailed,
                                    status  = 2
                                };
                            }
                        }

                        accounts.Add(account);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(accounts);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// AccountBalanceHistory
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void AccountBalanceHistory(object data)
        {
            try
            {
                bool clearCheck     = true;
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();

                List<BalanceHistoriesModel> getInfo = JsonConvert.DeserializeObject<List<BalanceHistoriesModel>>(js.Serialize(data));

                var accounts    = new List<BalanceHistoriesModel>();

                var account     = new BalanceHistoriesModel
                {
                    message     = "no balance history found",
                    status      = -1
                };

                accounts.Add(account);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postBalanceHistory",    mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@AccountGUID",         item.AccountGUID));
                        cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",           ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) accounts.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            account             = new BalanceHistoriesModel
                            {
                                ID              = Convert.ToInt32(dr["ID"]),
                                OldBalance      = Convert.ToDecimal(dr["OldBalance"]),
                                CurrentBalance  = Convert.ToDecimal(dr["CurrentBalance"]),
                                CreatedDate     = Convert.ToDateTime(dr["CreatedDate"]),
                                message         = "request is successfully",
                                status          = 1
                            };
                            accounts.Add(account);
                        }
                        else
                        {
                            account     = new BalanceHistoriesModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            accounts.Add(account);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(accounts);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// AccountLoginHistory
        /// </summary>
        /// <param name="data">data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void AccountLoginHistory(object data)
        {
            try
            {
                bool clearCheck     = true;
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();

                List<LoginHistoriesModel> getInfo = JsonConvert.DeserializeObject<List<LoginHistoriesModel>>(js.Serialize(data));

                var accounts    = new List<LoginHistoriesModel>();

                var account     = new LoginHistoriesModel
                {
                    message     = "no login history found",
                    status      = -1
                };

                accounts.Add(account);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_a_postLoginHistory",  mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@AccountGUID",     item.AccountGUID));
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) accounts.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            account             = new LoginHistoriesModel
                            {
                                ID              = Convert.ToInt64(dr["ID"]),
                                IpAddress       = dr["IpAddress"].ToString(),
                                RequestData     = dr["RequestData"].ToString(),
                                LastLoginDate   = Convert.ToDateTime(dr["LastLoginDate"]),
                                message         = "request is successfully",
                                status          = 1
                            };
                            accounts.Add(account);
                        }
                        else
                        {
                            account     = new LoginHistoriesModel
                            {
                                message = authenticationFailed,
                                status  = 2
                            };
                            accounts.Add(account);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(accounts);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void Dashboard(object token)
        {
            try
            {
                bool clearCheck = true;
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var dashboards = new List<ApiServiceModel>();

                var dashboard = new ApiServiceModel
                {
                    message = "no account found",
                    status = -1
                };

                dashboards.Add(dashboard);

                using (mainDatabase)
                {
                    SqlCommand cmd = new SqlCommand("usp_a_getDashboard", mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token", item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress", ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) dashboards.Clear();
                        int d = Convert.ToInt32(dr["Result"]);

                        if (d == 1)
                        {
                            dashboard = new ApiServiceModel
                            {
                                TotalAccount = Convert.ToInt32(dr["TotalAccount"]),
                                TotalActiveAccount = Convert.ToInt32(dr["TotalActiveAccount"]),
                                TotalBannedAccount = Convert.ToInt32(dr["TotalBannedAccount"]),
                                message = "request is successfully",
                                status = 1
                            };

                            dashboards.Add(dashboard);
                        }
                        else
                        {
                            dashboard = new ApiServiceModel
                            {
                                message = authenticationFailed,
                                status = 2
                            };
                            dashboards.Add(dashboard);
                        }

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(dashboards);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }






































































        /// <summary>
        /// AesOperation Shorter
        /// </summary>
        /// <param name="t">Encrypt or Decrypt type</param>
        /// <param name="value">value</param>
        /// <returns></returns>
        public string Aes(Operation type, string value)
        {
            try
            {
                if (type == 0) return AesOperation.EncryptString(authKey, value);
                else return AesOperation.DecryptString(authKey, value);
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// Aes Operation
        /// </summary>
        public enum Operation
        {
            Encrypt = 0,
            Decrypt = 1
        }

        /// <summary>
        /// for Google Recaptcha V3 model
        /// </summary>
        public class TokenResponse
        {
            [JsonProperty("success")]
            public bool Success { get; set; }

            [JsonProperty("score")]
            public decimal Score { get; set; }

            [JsonProperty("action")]
            public string Action { get; set; }

            [JsonProperty("error-codes")]
            public List<string> ErrorCodes { get; set; }
        }

        /// <summary>
        /// google recaptcha v3
        /// </summary>
        /// <param name="token">verify token</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void RecaptchaV3Vverify(string token)
        {
            try
            {
                if (!(string.IsNullOrEmpty(token)))
                {
                    var client      = new WebClient();
                    var secret      = ConfigurationManager.AppSettings["RecaptchaV3SecretKey"];
                    var googleReply = client.DownloadString(string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", secret, token));
                    var serializer  = new JavaScriptSerializer();
                    var reCaptcha   = serializer.Deserialize<TokenResponse>(googleReply);
                    developmentResponse(reCaptcha);
                }
                else errorResponse();
            }
            catch
            {
                errorResponse();
            }
        }

        /// <summary>
        /// Development Response
        /// </summary>
        /// <param name="array"></param>
        /// <param name="contentLength"></param>
        public void developmentResponse(object array)
        {
            try
            {
                var result = JsonConvert.SerializeObject(array, Formatting.None,
                new JsonSerializerSettings
                {
                    DefaultValueHandling    = DefaultValueHandling.Ignore,
                    NullValueHandling       = NullValueHandling.Ignore,
                    StringEscapeHandling    = StringEscapeHandling.EscapeNonAscii
                });
                Context.Response.Clear();
                Context.Response.ContentType = "application/json";
                Context.Response.AddHeader("content-length", result.Length.ToString());
                Context.Response.Write(result);
                Context.Response.Flush();
            }
            catch
            {
                Context.Response.Clear();
                Context.Response.Write(serviceOffline);
            }
        }

        /// <summary>
        /// Build Api Error Response
        /// </summary>
        public void errorResponse()
        {
            try
            {
                // API Services Error Message
                var errorMessages   = new List<ApiServiceModel>();
                var errorMessage    = new ApiServiceModel
                {
                    message         = serviceOffline,
                    status          = -1
                };
                errorMessages.Add(errorMessage);

                var result = JsonConvert.SerializeObject(errorMessages, Formatting.None,
                new JsonSerializerSettings
                {
                    DefaultValueHandling    = DefaultValueHandling.Ignore,
                    NullValueHandling       = NullValueHandling.Ignore,
                    StringEscapeHandling    = StringEscapeHandling.EscapeNonAscii
                });

                Context.Response.Clear();
                Context.Response.ContentType = "application/json";
                Context.Response.AddHeader("content-length", result.Length.ToString());
                Context.Response.Write(result);
                Context.Response.Flush();
            }
            catch
            {
                Context.Response.Clear();
                Context.Response.Write(serviceOffline);
            }
        }
    }
}
