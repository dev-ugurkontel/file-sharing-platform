﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using static betv1.Libraries.ExternalFunctions;

namespace betv1.Libraries
{
    public class ExternalFunctions
    {
        /// <summary>
        /// Generate Random String
        /// </summary>
        /// <param name="length">Max. Length 32767</param>
        /// <returns>string random string</returns>
        public static string GenerateString(Int16 length)
        {
            Random r = new Random();
            string c = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.-_!+%&/()=?*[{½$#£><";
            StringBuilder rS = new StringBuilder(length);
            for (int i = 0; i < length; i++) rS.Append(c[r.Next(c.Length)]);
            return rS.ToString();
        }

        public static string GenerateUrl(Int16 length)
        {
            Random r = new Random();
            string c = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            StringBuilder rS = new StringBuilder(length);
            for (int i = 0; i < length; i++) rS.Append(c[r.Next(c.Length)]);
            return rS.ToString();
        }

        /// <summary>
        /// Get Ip Address
        /// </summary>
        /// <returns>string Ip Address</returns>
        public static string GetIpAddress()
        {
            IPHostEntry ipEntry = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress[] addr = ipEntry.AddressList;
            return addr[addr.Length - 1].ToString();
        }

        /// <summary>
        /// EMail Verify
        /// </summary>
        /// <param name="eMail">mail</param>
        /// <returns>return bool</returns>
        public static bool EMailVerify(string eMail)
        {
            string r = @"^(([^<>()[\]\\.,;:\s@\""]+"
            + @"(\.[^<>()[\]\\.,;:\s@\""]+)*)|(\"".+\""))@"
            + @"((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"
            + @"\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+"
            + @"[a-zA-Z]{2,}))$";
            return Regex.IsMatch(eMail, r);
        }

        /// <summary>
        /// Send Mail
        /// </summary>
        /// <param name="receiver">receiver</param>
        /// <param name="subject">subject</param>
        /// <param name="body">body</param>
        /// <param name="mailType">mailType</param>
        [STAThread]
        public static void SendMail(    string      receiver, 
                                        string      subject, 
                                        string      body, 
                                        MailType    mailType)
        {
            string  APIKey                  = "";
            string  SecretKey               = "";
            string  From                    = "";
            string  MailHost                = "";
            int     MailPort                = 0;
            bool    EnableSsl               = true;
            bool    IsBodyHtml              = false;
            bool    UseDefaultCredentials   = true;

            switch (mailType)
            {
                case 0:
                    APIKey                  = ConfigurationManager.AppSettings["SendMail_Api_MailJetApiKey"];
                    SecretKey               = ConfigurationManager.AppSettings["SendMail_Api_MailJetSecretKey"];
                    From                    = ConfigurationManager.AppSettings["SendMail_Mail"];
                    MailHost                = ConfigurationManager.AppSettings["SendMail_Host"];
                    MailPort                = Convert.ToInt32(ConfigurationManager.AppSettings["SendMail_Port"]);
                    EnableSsl               = Convert.ToBoolean(ConfigurationManager.AppSettings["SendMail_EnableSsl"]);
                    IsBodyHtml              = Convert.ToBoolean(ConfigurationManager.AppSettings["SendMail_IsBodyHtml"]);
                    UseDefaultCredentials   = Convert.ToBoolean(ConfigurationManager.AppSettings["SendMail_UseDefaultCredentials"]);
                    break;
            }

            using (MailMessage message = new MailMessage())
            {
                message.From = new MailAddress(From);

                message.To.Add(new MailAddress(receiver));

                message.Subject     = subject;
                message.Body        = body;
                message.IsBodyHtml  = IsBodyHtml;

                SmtpClient client               = new SmtpClient(MailHost, MailPort);
                client.DeliveryMethod           = SmtpDeliveryMethod.Network;
                client.EnableSsl                = EnableSsl;
                client.UseDefaultCredentials    = UseDefaultCredentials;
                client.Credentials              = new NetworkCredential(APIKey, SecretKey);

                client.Send(message);
            }

        }

        /// <summary>
        /// Mail Type
        /// </summary>
        public enum MailType
        {
            support = 0
        }

        /// <summary>
        /// ResetPassword_MailTemplate
        /// </summary>
        /// <param name="eMail">eMail</param>
        /// <param name="password">password</param>
        /// <returns></returns>
        public static string ResetPassword_MailTemplate(string eMail, string password)
        {
            string body = "Destek Ekibi";
            try
            {
                using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/content/v1/mails/recovery/reset-password.html"))) body = reader.ReadToEnd();

                body = body.Replace("[siteName]", ConfigurationManager.AppSettings["SiteName"]);
                body = body.Replace("[siteUrl]", ConfigurationManager.AppSettings["SiteUrl"]);
                body = body.Replace("[date]", DateTime.Now.Year.ToString());

                body = body.Replace("[userEMail]", eMail);
                body = body.Replace("[userPassword]", password);
            }
            catch (Exception)
            {
                body = "Teknik bir hata oluştu, lütfen bu hatayı destek birimine bildirin.";
            }
            return body;
        }

        /// <summary>
        /// Register_MailTemplate
        /// </summary>
        /// <param name="eMail">eMail</param>
        /// <param name="password">password</param>
        /// <returns></returns>
        public static string Register_MailTemplate( string eMail, 
                                                    string password, 
                                                    string userName)
        {
            string body = "Destek Ekibi";
            try
            {
                using (StreamReader reader = new StreamReader(HttpContext.Current.Server.MapPath("~/content/v1/mails/account/register.html"))) body = reader.ReadToEnd();

                body = body.Replace("[siteName]", ConfigurationManager.AppSettings["SiteName"]);
                body = body.Replace("[siteUrl]", ConfigurationManager.AppSettings["SiteUrl"]);
                body = body.Replace("[date]", DateTime.Now.Year.ToString());

                body = body.Replace("[userEMail]", eMail);
                body = body.Replace("[userPassword]", password);
                body = body.Replace("[userName]", userName);
            }
            catch (Exception)
            {
                body = "Teknik bir hata oluştu, lütfen bu hatayı destek birimine bildirin.";
            }
            return body;
        }

    }
}