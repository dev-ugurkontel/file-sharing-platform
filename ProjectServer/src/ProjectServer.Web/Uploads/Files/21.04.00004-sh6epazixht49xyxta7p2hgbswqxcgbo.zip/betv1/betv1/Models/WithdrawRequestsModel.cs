﻿using System;

namespace betv1.Models
{
    public class WithdrawRequestsModel : ApiServiceModel
    {
        public int      ID                          { get; set; }
        public int      AccountID                   { get; set; }
        public byte     TradingStatus               { get; set; }
        public string   TradingIBAN                 { get; set; }
        public decimal  TradingAmount               { get; set; }
        public decimal  TradingSuccessfulAmount     { get; set; }
        public string   TradingGUID                 { get; set; }
        public DateTime TradingRequestDate          { get; set; }
        public DateTime LastUpdateDate              { get; set; }

        // DataTables
        public string   TradingAmountStr            { get; set; }
        public string   TradingSuccessfulAmountStr  { get; set; }

        // API
        public string   message                     { get; set; }
        public int      status                      { get; set; }

        // Others
        public string   UserName                    { get; set; }
        public decimal  Balance                     { get; set; }
        public byte     Action                      { get; set; }
        public decimal  ManuelAmount                { get; set; }
    }
}