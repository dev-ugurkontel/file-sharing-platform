﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;
using betv1.Libraries;
using betv1.Models;
using Newtonsoft.Json;
using static betv1.Libraries.DatabaseConnection;
using static betv1.Libraries.ExternalFunctions;

namespace betv1.Api.v1
{
    /// <summary>
    /// Web Services API v1 methods
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    [ScriptService]
    public class Main : WebService
    {
        // Database Connections
        SqlConnection mainDatabase = new DatabaseConnection().Connect(Database.Main);

        string  authenticationFailed    = "authentication failed";
        string  requestFailed           = "request failed";
        string  serviceOffline          = "api v1 services are now offline";
        string  authKey                 = ConfigurationManager.AppSettings["AuthKey"];

        /// <summary>
        /// api/v1/bets (getBets)
        /// </summary>
        /// <param name="betTypeID">Bet type id, 1 for football, 2 for basketball</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Bets(long betTypeID)
        {
            bool clearCheck = true;
            var bets    = new List<BetsModel>();

            var bet1    = new BetsModel
            { 
                message = "no upcoming competition found",
                status  = -1
            };

            bets.Add(bet1);

            var bet2    = new BetsModel
            {
                message = "no upcoming competition found",
                status  = -1
            };

            try
            {
                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postBets",    mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@BetTypeID",   betTypeID));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (clearCheck) bets.Clear();

                        if (betTypeID == 1)
                        {
                            // football
                            bet1 = new BetsModel
                            {
                                ID                  = Convert.ToInt64(dr["ID"]),
                                BetTypeID           = Convert.ToByte(dr["BetTypeID"]),
                                TournamentID        = Convert.ToInt16(dr["TournamentID"]),
                                BetStartDate        = Convert.ToDateTime(dr["BetStartDate"]),
                                BetEndDate          = Convert.ToDateTime(dr["BetEndDate"]),
                                IsOpen              = Convert.ToBoolean(dr["IsOpen"]),
                                MinAmount           = Convert.ToDecimal(dr["MinAmount"]),
                                MaxAmount           = Convert.ToDecimal(dr["MaxAmount"]),
                                BetName             = dr["BetName"].ToString(),
                                BetCode             = dr["BetCode"].ToString(),
                                MinPlayableMatches  = Convert.ToByte(dr["MinPlayableMatches"]),
                                BetDescription      = dr["BetDescription"].ToString(),
                                BetCommission       = Convert.ToDecimal(dr["BetCommission"]),
                                LastUpdateDate      = Convert.ToDateTime(dr["LastUpdateDate"]),
                                _01                 = Convert.ToDecimal(dr["_01"]).ToString("0.00").Replace(",", "."),
                                _02                 = Convert.ToDecimal(dr["_02"]).ToString("0.00").Replace(",", "."),
                                _03                 = Convert.ToDecimal(dr["_03"]).ToString("0.00").Replace(",", "."),
                                _04                 = Convert.ToDecimal(dr["_04"]).ToString("0.00").Replace(",", "."),
                                _05                 = Convert.ToDecimal(dr["_05"]).ToString("0.00").Replace(",", "."),
                                _06                 = Convert.ToDecimal(dr["_06"]).ToString("0.00").Replace(",", "."),
                                _07                 = Convert.ToDecimal(dr["_07"]).ToString("0.00").Replace(",", "."),
                                _08                 = Convert.ToDecimal(dr["_08"]).ToString("0.00").Replace(",", "."),
                                _09                 = Convert.ToDecimal(dr["_09"]).ToString("0.00").Replace(",", "."),
                                _10                 = Convert.ToDecimal(dr["_10"]).ToString("0.00").Replace(",", "."),
                                _11                 = Convert.ToDecimal(dr["_11"]).ToString("0.00").Replace(",", "."),
                                _12                 = Convert.ToDecimal(dr["_12"]).ToString("0.00").Replace(",", "."),
                                _13                 = Convert.ToDecimal(dr["_13"]).ToString("0.00").Replace(",", "."),
                                _14                 = Convert.ToDecimal(dr["_14"]).ToString("0.00").Replace(",", "."),
                                _15                 = Convert.ToDecimal(dr["_15"]).ToString("0.00").Replace(",", "."),
                                _16                 = Convert.ToDecimal(dr["_16"]).ToString("0.00").Replace(",", "."),
                                _17                 = Convert.ToDecimal(dr["_17"]).ToString("0.00").Replace(",", "."),
                                _18                 = Convert.ToDecimal(dr["_18"]).ToString("0.00").Replace(",", "."),
                                _19                 = Convert.ToDecimal(dr["_19"]).ToString("0.00").Replace(",", "."),
                                _20                 = Convert.ToDecimal(dr["_20"]).ToString("0.00").Replace(",", "."),
                                _21                 = Convert.ToDecimal(dr["_21"]).ToString("0.00").Replace(",", "."),
                                _22                 = Convert.ToDecimal(dr["_22"]).ToString("0.00").Replace(",", "."),
                                _23                 = Convert.ToDecimal(dr["_23"]).ToString("0.00").Replace(",", "."),
                                _24                 = Convert.ToDecimal(dr["_24"]).ToString("0.00").Replace(",", "."),
                                _25                 = Convert.ToDecimal(dr["_25"]).ToString("0.00").Replace(",", "."),
                                _26                 = Convert.ToDecimal(dr["_26"]).ToString("0.00").Replace(",", "."),
                                BetTypeCommission   = Convert.ToDecimal(dr["BetTypeCommission"]),
                                TournamentCommision = Convert.ToDecimal(dr["TournamentCommision"]),
                                message             = "request is successfully",
                                status              = 1
                            };
                            bets.Add(bet1);
                        }
                        else if (betTypeID == 2)
                        {
                            // basketball
                            bet2 = new BetsModel
                            {
                                ID                  = Convert.ToInt64(dr["ID"]),
                                BetTypeID           = Convert.ToByte(dr["BetTypeID"]),
                                TournamentID        = Convert.ToInt16(dr["TournamentID"]),
                                BetStartDate        = Convert.ToDateTime(dr["BetStartDate"]),
                                BetEndDate          = Convert.ToDateTime(dr["BetEndDate"]),
                                IsOpen              = Convert.ToBoolean(dr["IsOpen"]),
                                MinAmount           = Convert.ToDecimal(dr["MinAmount"]),
                                MaxAmount           = Convert.ToDecimal(dr["MaxAmount"]),
                                BetName             = dr["BetName"].ToString(),
                                BetCode             = dr["BetCode"].ToString(),
                                MinPlayableMatches  = Convert.ToByte(dr["MinPlayableMatches"]),
                                BetDescription      = dr["BetDescription"].ToString(),
                                BetCommission       = Convert.ToDecimal(dr["BetCommission"]),
                                LastUpdateDate      = Convert.ToDateTime(dr["LastUpdateDate"]),
                                _01                 = Convert.ToDecimal(dr["_01"]).ToString("0.00").Replace(",", "."),
                                _02                 = Convert.ToDecimal(dr["_02"]).ToString("0.00").Replace(",", "."),
                                _03                 = Convert.ToDecimal(dr["_03"]).ToString("0.00").Replace(",", "."),
                                _04                 = Convert.ToDecimal(dr["_04"]).ToString("0.00").Replace(",", "."),
                                _05                 = Convert.ToDecimal(dr["_05"]).ToString("0.00").Replace(",", "."),
                                _06                 = Convert.ToDecimal(dr["_06"]).ToString("0.00").Replace(",", "."),
                                _07                 = Convert.ToDecimal(dr["_07"]).ToString("0.00").Replace(",", "."),
                                _08                 = Convert.ToDecimal(dr["_08"]).ToString("0.00").Replace(",", "."),
                                _09                 = Convert.ToDecimal(dr["_09"]).ToString("0.00").Replace(",", "."),
                                _10                 = Convert.ToDecimal(dr["_10"]).ToString("0.00").Replace(",", "."),
                                _11                 = Convert.ToDecimal(dr["_11"]).ToString("0.00").Replace(",", "."),
                                _12                 = Convert.ToDecimal(dr["_12"]).ToString("0.00").Replace(",", "."),
                                _13                 = Convert.ToDecimal(dr["_13"]).ToString("0.00").Replace(",", "."),
                                _14                 = Convert.ToDecimal(dr["_14"]).ToString("0.00").Replace(",", "."),
                                _15                 = Convert.ToDecimal(dr["_15"]).ToString("0.00").Replace(",", "."),
                                _16                 = Convert.ToDecimal(dr["_16"]).ToString("0.00").Replace(",", "."),
                                _17                 = Convert.ToDecimal(dr["_17"]).ToString("0.00").Replace(",", "."),
                                _18                 = Convert.ToDecimal(dr["_18"]).ToString("0.00").Replace(",", "."),
                                _19                 = Convert.ToDecimal(dr["_19"]).ToString("0.00").Replace(",", "."),
                                _20                 = Convert.ToDecimal(dr["_20"]).ToString("0.00").Replace(",", "."),
                                _21                 = Convert.ToDecimal(dr["_21"]).ToString("0.00").Replace(",", "."),
                                _22                 = Convert.ToDecimal(dr["_22"]).ToString("0.00").Replace(",", "."),
                                _23                 = Convert.ToDecimal(dr["_23"]).ToString("0.00").Replace(",", "."),
                                _24                 = Convert.ToDecimal(dr["_24"]).ToString("0.00").Replace(",", "."),
                                _25                 = Convert.ToDecimal(dr["_25"]).ToString("0.00").Replace(",", "."),
                                _26                 = Convert.ToDecimal(dr["_26"]).ToString("0.00").Replace(",", "."),
                                _27                 = Convert.ToDecimal(dr["_27"]).ToString("0.00").Replace(",", "."),
                                _28                 = Convert.ToDecimal(dr["_28"]).ToString("0.00").Replace(",", "."),
                                _29                 = Convert.ToDecimal(dr["_29"]).ToString("0.00").Replace(",", "."),
                                _30                 = Convert.ToDecimal(dr["_30"]).ToString("0.00").Replace(",", "."),
                                _31                 = Convert.ToDecimal(dr["_31"]).ToString("0.00").Replace(",", "."),
                                _32                 = Convert.ToDecimal(dr["_32"]).ToString("0.00").Replace(",", "."),
                                _33                 = Convert.ToDecimal(dr["_33"]).ToString("0.00").Replace(",", "."),
                                _34                 = Convert.ToDecimal(dr["_34"]).ToString("0.00").Replace(",", "."),
                                _35                 = Convert.ToDecimal(dr["_35"]).ToString("0.00").Replace(",", "."),
                                _36                 = Convert.ToDecimal(dr["_36"]).ToString("0.00").Replace(",", "."),
                                BetTypeCommission   = Convert.ToDecimal(dr["BetTypeCommission"]),
                                TournamentCommision = Convert.ToDecimal(dr["TournamentCommision"]),
                                message             = "request is successfully",
                                status              = 1
                            };
                            bets.Add(bet2);
                        }
                        

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(bets);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// for Coupon model
        /// </summary>
        public class CouponDetailsLocalModel
        {
            public string   addedDate               { get; set; }
            public string   betCode                 { get; set; }
            public decimal  betCommission           { get; set; }
            public string   betEndDate              { get; set; }
            public long     betID                   { get; set; }
            public string   betName                 { get; set; }
            public decimal  betTypeCommission       { get; set; }
            public string   id                      { get; set; }
            public bool     isOpen                  { get; set; }
            public decimal  maxAmount               { get; set; }
            public decimal  minAmount               { get; set; }
            public byte     minPlayableMatches      { get; set; }
            public string   selectedBetOption       { get; set; }
            public decimal  tournamentCommision     { get; set; }
            public Int16    tournamentID            { get; set; }
            public decimal  winningRateForDetail    { get; set; }
            public decimal  earnedAmount            { get; set; }
        }

        /// <summary>
        /// api/v1/coupon (postCoupon)
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Coupon( object  data, 
                            object  token, 
                            decimal earnedAmountNoTax, 
                            decimal earnedAmountWithTax, 
                            decimal amountPlayed)
        {
            var coupons = new List<ApiServiceModel>();
            
            
                bool control        = false;
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();
                string tokenStorage = "";

                List<ApiServiceModel> getInfo1 = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                foreach (var item1 in getInfo1)
                {
                    tokenStorage = item1.Token;
                }

                var coupon = new ApiServiceModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                using (mainDatabase)
                {
                    SqlCommand cmd1     = new SqlCommand("usp_postCoupon",  mainDatabase);
                    cmd1.CommandType    = CommandType.StoredProcedure;

                    cmd1.Parameters.Add(new SqlParameter("@CouponOrDetail", 1));
                    cmd1.Parameters.Add(new SqlParameter("@AmountPlayed",   amountPlayed));

                    cmd1.Parameters.Add(new SqlParameter("@Token",          tokenStorage));

                    cmd1.Parameters.Add(new SqlParameter("@LastIpAddress",  ipAddress));

                    mainDatabase.Open();

                    switch ((int)cmd1.ExecuteScalar())
                    {
                        case 1:
                            coupon      = new ApiServiceModel
                            {
                                message = "coupon created successfully",
                                status  = 1
                            };
                            control     = true;
                            break;
                        case 2:
                            coupon      = new ApiServiceModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            control     = false;
                            break;
                        case 3:
                            coupon      = new ApiServiceModel
                            {
                                message = "you have insufficient funds to play this coupon",
                                status  = 3
                            };
                            control     = false;
                            break;
                    }

                    if (control)
                    {
                        List<CouponDetailsLocalModel> getInfo2 = JsonConvert.DeserializeObject<List<CouponDetailsLocalModel>>(js.Serialize(data));

                        decimal winningRateForDetail = 1;

                        foreach (var item2 in getInfo2)
                        {
                            SqlCommand cmd2     = new SqlCommand("usp_postCoupon",      mainDatabase);
                            cmd2.CommandType    = CommandType.StoredProcedure;

                            cmd2.Parameters.Add(new SqlParameter("@CouponOrDetail",     2));
                            cmd2.Parameters.Add(new SqlParameter("@AmountPlayed",       amountPlayed));
                            cmd2.Parameters.Add(new SqlParameter("@BetID",              item2.betID));
                            cmd2.Parameters.Add(new SqlParameter("@AddedDate",          item2.addedDate));
                            cmd2.Parameters.Add(new SqlParameter("@SelectedBetOption",  item2.selectedBetOption));
                            cmd2.Parameters.Add(new SqlParameter("@WinningRate",        item2.winningRateForDetail));

                            winningRateForDetail = (winningRateForDetail * item2.winningRateForDetail);

                            cmd2.Parameters.Add(new SqlParameter("@Token",              tokenStorage));

                            cmd2.Parameters.Add(new SqlParameter("@LastIpAddress",      ipAddress));

                            cmd2.ExecuteScalar();
                        }

                        // Update WinningRate and EarnedAmount
                        SqlCommand cmd3     = new SqlCommand("usp_postCoupon",           mainDatabase);
                        cmd3.CommandType    = CommandType.StoredProcedure;

                        cmd3.Parameters.Add(new SqlParameter("@CouponOrDetail",         3));
                        cmd3.Parameters.Add(new SqlParameter("@AmountPlayed",           amountPlayed));
                        cmd3.Parameters.Add(new SqlParameter("@EarnedAmountNoTax",      earnedAmountNoTax));
                        cmd3.Parameters.Add(new SqlParameter("@EarnedAmountWithTax",    earnedAmountWithTax));
                        cmd3.Parameters.Add(new SqlParameter("@WinningRate",            winningRateForDetail));

                        cmd3.Parameters.Add(new SqlParameter("@Token",                  tokenStorage));

                        cmd3.Parameters.Add(new SqlParameter("@LastIpAddress",          ipAddress));

                        cmd3.ExecuteScalar();
                    }

                    mainDatabase.Close();

                    coupons.Add(coupon);
                    developmentResponse(coupons);
                }
            
        }

        /// <summary>
        /// api/v1/auth (postAuth)
        /// </summary>
        /// <param name="eMail">User email</param>
        /// <param name="password">User password</param>
        /// <param name="data">User device data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Auth(   string eMail,
                            string password,
                            string data)
        {
            var accounts        = new List<AccountsModel>();
            var wrongRequests   = new List<AccountsModel>();

            var wrongRequest = new AccountsModel
            {
                message = "unable to respond to incorrect request",
                status  = 2
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (eMail.Length    >= 6    &&
                    eMail.Length    <= 150  &&
                    password.Length >= 6    &&
                    password.Length <= 32)
                {
                    string token    = AesOperation.EncryptString(authKey, GenerateString(256));

                    var account     = new AccountsModel
                    {
                        message     = authenticationFailed,
                        status      = -1
                    };

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_postAuth",        mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@HashEMail",       Aes(Operation.Encrypt, eMail)));
                        cmd.Parameters.Add(new SqlParameter("@HashPassword",    Aes(Operation.Encrypt, password)));
                        cmd.Parameters.Add(new SqlParameter("@Token",           token));
                        cmd.Parameters.Add(new SqlParameter("@Data",            data));
                        cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   GetIpAddress()));

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            account = new AccountsModel
                            {
                                ID              = Convert.ToInt32(dr["ID"]),
                                UserName        = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                EMail           = Aes(Operation.Decrypt, dr["EMail"].ToString()),
                                AccountRole     = Convert.ToByte(dr["AccountRole"]),
                                Balance         = Convert.ToDecimal(dr["Balance"]),
                                IsLoggedIn      = true,
                                RegisteredDate  = Convert.ToDateTime(dr["RegisteredDate"]),
                                Token           = token,
                                ExpiredDate     = Convert.ToDateTime(dr["ExpiredDate"]),
                                message         = "authentication was successfully",
                                status          = 1
                            };
                        }

                        accounts.Add(account);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(accounts);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// post new user register
        /// </summary>
        /// <param name="eMail">user email</param>
        /// <param name="password">user password</param>
        /// <param name="userName">username</param>
        /// <param name="data">location api data</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Register(   string eMail, 
                                string password, 
                                string userName, 
                                string data)
        {
            var accounts        = new List<AccountsModel>();
            var wrongRequests   = new List<AccountsModel>();

            var wrongRequest    = new AccountsModel
            {
                message = "unable to respond to incorrect request",
                status  = 4
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (eMail.Length    >= 6    &&
                    eMail.Length    <= 150  &&
                    userName.Length >= 3    &&
                    userName.Length <= 26   &&
                    password.Length >= 6    &&
                    password.Length <= 32   &&
                    EMailVerify(eMail))
                {
                    string hashEmail    = Aes(Operation.Encrypt, eMail);
                    string hashUserName = Aes(Operation.Encrypt, userName);
                    string hashPassword = Aes(Operation.Encrypt, password);

                    var account = new AccountsModel
                    {
                        message = authenticationFailed,
                        status = 4
                    };

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_postRegister",    mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@HashEMail",       hashEmail));
                        cmd.Parameters.Add(new SqlParameter("@HashUserName",    hashUserName));
                        cmd.Parameters.Add(new SqlParameter("@HashPassword",    hashPassword));
                        cmd.Parameters.Add(new SqlParameter("@Token",           GenerateString(256)));
                        cmd.Parameters.Add(new SqlParameter("@Data",            data));
                        cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   GetIpAddress()));

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            byte d = Convert.ToByte(dr["Result"]);

                            if (d == 1)
                            {
                                account = new AccountsModel
                                {
                                    ID              = Convert.ToInt32(dr["ID"]),
                                    UserName        = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                                    EMail           = Aes(Operation.Decrypt, dr["EMail"].ToString()),
                                    AccountRole     = Convert.ToByte(dr["AccountRole"]),
                                    Balance         = Convert.ToDecimal(dr["Balance"]),
                                    IsLoggedIn      = true,
                                    RegisteredDate  = Convert.ToDateTime(dr["RegisteredDate"]),
                                    Token           = dr["Token"].ToString(),
                                    ExpiredDate     = Convert.ToDateTime(dr["ExpiredDate"]),
                                    message         = "authentication was successfully",
                                    status          = 1
                                };

                                // Send Mail
                                SendMail(eMail,
                                        "Aramıza hoş geldin!",
                                        Register_MailTemplate(  eMail,
                                                                password,
                                                                userName),
                                        MailType.support);
                            }
                            else if (d == 2)
                            {
                                account     = new AccountsModel
                                {
                                    message = "e-mail cannot be used",
                                    status  = 2
                                };
                            }
                            else if (d == 3)
                            {
                                account     = new AccountsModel
                                {
                                    message = "username cannot be used",
                                    status  = 3
                                };
                            }
                        }

                        accounts.Add(account);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(accounts);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void ResetPassword(  string eMail, 
                                    string data)
        {
            var accounts        = new List<AccountsModel>();
            var wrongRequests   = new List<AccountsModel>();

            var wrongRequest    = new AccountsModel
            {
                message = "unable to respond to incorrect request",
                status  = 2
            };

            wrongRequests.Add(wrongRequest);

            try
            {
                if (eMail.Length >= 2 &&
                    eMail.Length <= 150)
                {
                    var account = new AccountsModel
                    {
                        message = authenticationFailed,
                        status  = -1
                    };

                    using (mainDatabase)
                    {
                        SqlCommand cmd  = new SqlCommand("usp_postResetPassword", mainDatabase);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@EMail",   Aes(Operation.Encrypt, eMail)));
                        cmd.Parameters.Add(new SqlParameter("@Data",    data));

                        mainDatabase.Open();

                        var dr = cmd.ExecuteReader();

                        while (dr.Read())
                        {
                            if (dr.HasRows)
                            {
                                // Send Mail
                                SendMail(   eMail, 
                                            "Şifre Sıfırlama Talebiniz",
                                            ResetPassword_MailTemplate( eMail, 
                                                                        Aes(Operation.Decrypt, dr["HashPassword"].ToString())), 
                                            MailType.support);
                            }                            
                        }

                        account = new AccountsModel
                        {
                            message = "request is successfully",
                            status  = 1
                        };

                        accounts.Add(account);

                        dr.Close();
                        mainDatabase.Close();

                        developmentResponse(accounts);
                    }
                }
                else
                {
                    mainDatabase.Close();
                    developmentResponse(wrongRequest);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// get user account balance
        /// </summary>
        /// <param name="token">verify token</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Balance(object token)
        {
            var accounts    = new List<AccountsModel>();
            var js          = new JavaScriptSerializer();

            try
            {
                var account = new AccountsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                accounts.Add(account);

                using (mainDatabase)
                {
                    List<AccountsModel> getInfo = JsonConvert.DeserializeObject<List<AccountsModel>>(js.Serialize(token));

                    SqlCommand cmd  = new SqlCommand("usp_postBalance",     mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   GetIpAddress()));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (dr.HasRows)
                        {
                            accounts.Clear();

                            if (Convert.ToInt32(dr["Result"]) == 1)
                            {
                                account     = new AccountsModel
                                {
                                    Balance = Convert.ToDecimal(dr["Balance"]),
                                    message = "authorization verification successfully",
                                    status  = 1
                                };
                            }
                            else
                            {
                                account     = new AccountsModel
                                {
                                    message = "authentication failedd",
                                    status  = 2
                                };
                            }
                            

                            accounts.Add(account);
                        }
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(accounts);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// get competition counts
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void CompetitionCount()
        {
            var competitions = new List<ApiServiceModel>();

            try
            {
                var competition = new ApiServiceModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                competitions.Add(competition);

                SqlCommand cmd  = new SqlCommand("usp_getCompetitionCount", mainDatabase);
                cmd.CommandType = CommandType.StoredProcedure;

                mainDatabase.Open();

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        competitions.Clear();

                        competition = new ApiServiceModel
                        {
                            ActiveFootballCompetitions      = Convert.ToInt64(dr["Football"]),
                            ActiveBasketballCompetitions    = Convert.ToInt64(dr["Basketball"]),
                            message                         = "request is successfully",
                            status                          = 1
                        };

                        competitions.Add(competition);
                    }    
                }

                dr.Close();
                mainDatabase.Close();

                developmentResponse(competitions);
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// post user coupons
        /// </summary>
        /// <param name="status">coupon status</param>
        /// <param name="token">verify token</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Coupons(byte status, 
                            object token)
        {
            var coupons     = new List<CouponsModel>();
            bool clearCheck = true;

            var coupon  = new CouponsModel
            {
                message = requestFailed,
                status  = 2
            };

            coupons.Add(coupon);

            try
            {
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();
                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));
                            
                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postCoupons",     mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CouponStatus",    status));

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if  (dr.HasRows)
                        {
                            byte d = Convert.ToByte(dr["Result"]);

                            if (clearCheck) coupons.Clear();

                            if (d == 1)
                            {
                                coupon = new CouponsModel
                                {
                                    ID                      = Convert.ToInt64(dr["ID"]),
                                    CreatedDate             = Convert.ToDateTime(dr["CreatedDate"]),
                                    BetAmount               = Convert.ToInt64(dr["BetAmount"]),
                                    WinningRateStr          = Convert.ToDecimal(dr["WinningRate"]).ToString("0.00").Replace(",", "."),
                                    AmountPlayedStr         = Convert.ToDecimal(dr["AmountPlayed"]).ToString("0.00").Replace(",", "."),
                                    EarnedAmountWithTaxStr  = Convert.ToDecimal(dr["EarnedAmountWithTax"]).ToString("0.00").Replace(",", "."),
                                    CouponStatus            = Convert.ToByte(dr["CouponStatus"]),
                                    message                 = "request is successfully",
                                    status                  = 1
                                };
                            }
                            else if (d == 2)
                            {
                                coupon = new CouponsModel
                                {
                                    message = requestFailed,
                                    status = 2
                                };
                            }

                            coupons.Add(coupon);

                            clearCheck = false;
                        }                        
                    }

                    dr.Close();
                    mainDatabase.Close();

                    
                    developmentResponse(coupons);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// CouponDetails2LocalModel
        /// </summary>
        public class CouponDetails2LocalModel
        {
            public long     ID                      { get; set; }
            public string   BetCode                 { get; set; }
            public string   BetName                 { get; set; }
            public byte     MinPlayableMatches      { get; set; }
            public string   SelectedBetOption       { get; set; }
            public DateTime BetEndDate              { get; set; }
            public Int16    TeamOneHalfTimeScore    { get; set; }
            public Int16    TeamOneFullTimeScore    { get; set; }
            public Int16    TeamTwoHalfTimeScore    { get; set; }
            public Int16    TeamTwoFullTimeScore    { get; set; }
            public byte     CouponDetailStatus      { get; set; }
            public byte     BetTypeID               { get; set; }

            // dataTables
            public string   WinningRateStr          { get; set; }

            // API
            public string   message                 { get; set; }
            public Int16    status                  { get; set; }
        }

        /// <summary>
        /// get user coupon details
        /// </summary>
        /// <param name="couponId">coupon id</param>
        /// <param name="token">verify token</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void CouponDetails(long couponId, object token)
        {
            var couponDetails   = new List<CouponDetails2LocalModel>();
            bool clearCheck     = true;

            var couponDetail    = new CouponDetails2LocalModel
            {
                message = requestFailed,
                status  = -1
            };

            couponDetails.Add(couponDetail);

            try
            {
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();
                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_getCouponDetails",    mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add(new SqlParameter("@CouponID",            couponId));

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        byte d = Convert.ToByte(dr["Result"]);

                        if (clearCheck) couponDetails.Clear();

                        if (d == 1)
                        {
                            couponDetail = new CouponDetails2LocalModel
                            {
                                ID                      = Convert.ToInt64(dr["ID"]),
                                BetCode                 = dr["BetCode"].ToString(),
                                BetName                 = dr["BetName"].ToString(),
                                MinPlayableMatches      = Convert.ToByte(dr["MinPlayableMatches"]),
                                SelectedBetOption       = dr["SelectedBetOption"].ToString(),
                                WinningRateStr          = Convert.ToDecimal(dr["WinningRate"]).ToString("0.00").Replace(",", "."),
                                BetEndDate              = Convert.ToDateTime(dr["BetEndDate"]),
                                TeamOneHalfTimeScore    = Convert.ToInt16(dr["TeamOneHalfTimeScore"]),
                                TeamOneFullTimeScore    = Convert.ToInt16(dr["TeamOneFullTimeScore"]),
                                TeamTwoHalfTimeScore    = Convert.ToInt16(dr["TeamTwoHalfTimeScore"]),
                                TeamTwoFullTimeScore    = Convert.ToInt16(dr["TeamTwoFullTimeScore"]),
                                CouponDetailStatus      = Convert.ToByte(dr["CouponDetailStatus"]),
                                BetTypeID               = Convert.ToByte(dr["BetTypeID"]),
                                message                 = "request is successfully",
                                status                  = 1
                            };
                        }
                        else if (d == 2)
                        {
                            couponDetail    = new CouponDetails2LocalModel
                            {
                                message     = requestFailed,
                                status      = 2
                            };
                        }

                        couponDetails.Add(couponDetail);

                        clearCheck = false;
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(couponDetails);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// OldDepositRequests
        /// </summary>
        /// <param name="token"></param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void OldDepositRequests(object token)
        {
            var depositRequests = new List<DepositRequestsModel>();
            bool clearCheck     = true;

            var depositRequest  = new DepositRequestsModel
            {
                message = requestFailed,
                status  = -1
            };

            depositRequests.Add(depositRequest);

            try
            {
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();
                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                using (mainDatabase)
                {
                    SqlCommand cmd = new SqlCommand("usp_postOldDepositRequests", mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token", item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress", ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (dr.HasRows)
                        {
                            byte d = Convert.ToByte(dr["Result"]);

                            if (d == 1)
                            {
                                if (clearCheck) depositRequests.Clear();

                                depositRequest          = new DepositRequestsModel
                                {
                                    ID                  = Convert.ToInt32(dr["ID"]),
                                    TradingIBAN         = dr["TradingIBAN"].ToString(),
                                    TradingAmountStr    = Convert.ToDecimal(dr["TradingAmount"]).ToString("0.00").Replace(",", "."),
                                    TradingSuccessfulAmountStr = Convert.ToDecimal(dr["TradingSuccessfulAmount"]).ToString("0.00").Replace(",", "."),
                                    TradingHour         = dr["TradingHour"].ToString(),
                                    TradingRequestDate  = Convert.ToDateTime(dr["TradingRequestDate"]),
                                    TradingStatus       = Convert.ToByte(dr["TradingStatus"]),
                                    TradingGUID         = dr["TradingGUID"].ToString(),
                                    message             = "request is successfully",
                                    status              = 1
                                };
                            }
                            else if (d == 2)
                            {
                                if (clearCheck) depositRequests.Clear();

                                depositRequest  = new DepositRequestsModel
                                {
                                    message     = "request is successfully",
                                    status      = 2
                                };
                            }

                            depositRequests.Add(depositRequest);

                            clearCheck = false;
                        }                        
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(depositRequests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// CancelDepositRequests
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="guid">guid</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void CancelDepositRequests(object token, string guid)
        {
            var requests = new List<ApiServiceModel>();

            try
            {
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var request = new ApiServiceModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                requests.Add(request);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postCancelDepositRequests",   mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",                   item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",               ipAddress));

                    cmd.Parameters.Add(new SqlParameter("@TradingGUID",                 guid));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            requests.Add(request);
                            break;
                        case 2:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            requests.Add(request);
                            break;

                    }

                    mainDatabase.Close();

                    developmentResponse(requests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// Withdraw
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="tradingAmount">tradingAmount</param>
        /// <param name="tradingIBAN">tradingIBAN</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Withdraw(object token, decimal tradingAmount, string tradingIBAN)
        {
            var requests = new List<ApiServiceModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var request = new ApiServiceModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                requests.Add(request);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postWithdrawRequest", mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",           item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       ipAddress));

                    cmd.Parameters.Add(new SqlParameter("@TradingAmount",       tradingAmount));
                    cmd.Parameters.Add(new SqlParameter("@TradingIBAN",         tradingIBAN));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            requests.Add(request);
                            break;
                        case 2:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            requests.Add(request);
                            break;
                        case 3:
                            requests.Clear();
                            request = new ApiServiceModel
                            {
                                message = "you don't have enough money to request a withdrawal",
                                status = 3
                            };
                            requests.Add(request);
                            break;
                    }

                    mainDatabase.Close();

                    developmentResponse(requests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// OldWithdrawRequests
        /// </summary>
        /// <param name="token"></param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void OldWithdrawRequests(object token)
        {
            var depositRequests = new List<WithdrawRequestsModel>();
            bool clearCheck     = true;

            var depositRequest = new WithdrawRequestsModel
            {
                message = requestFailed,
                status  = -1
            };

            depositRequests.Add(depositRequest);

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();
                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postOldWithdrawRequests", mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",               item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",           ipAddress));

                    mainDatabase.Open();

                    var dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        if (dr.HasRows)
                        {
                            byte d = Convert.ToByte(dr["Result"]);

                            if (d == 1)
                            {
                                if (clearCheck) depositRequests.Clear();

                                depositRequest          = new WithdrawRequestsModel
                                {
                                    ID                  = Convert.ToInt32(dr["ID"]),
                                    TradingIBAN         = dr["TradingIBAN"].ToString(),
                                    TradingAmountStr    = Convert.ToDecimal(dr["TradingAmount"]).ToString("0.00").Replace(",", "."),
                                    TradingSuccessfulAmountStr = Convert.ToDecimal(dr["TradingSuccessfulAmount"]).ToString("0.00").Replace(",", "."),
                                    TradingRequestDate  = Convert.ToDateTime(dr["TradingRequestDate"]),
                                    TradingStatus       = Convert.ToByte(dr["TradingStatus"]),
                                    TradingGUID         = dr["TradingGUID"].ToString(),
                                    message             = "request is successfully",
                                    status              = 1
                                };
                            }
                            else if (d == 2)
                            {
                                if (clearCheck) depositRequests.Clear();

                                depositRequest  = new WithdrawRequestsModel
                                {
                                    message     = "request is successfully",
                                    status      = 2
                                };
                            }

                            depositRequests.Add(depositRequest);

                            clearCheck = false;
                        }
                    }

                    dr.Close();
                    mainDatabase.Close();

                    developmentResponse(depositRequests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// CancelWithdrawRequests
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="guid">guid</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void CancelWithdrawRequests(object token, string guid)
        {
            var requests = new List<ApiServiceModel>();

            try
            {
                var js              = new JavaScriptSerializer();
                string ipAddress    = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var request = new ApiServiceModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                requests.Add(request);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postCancelWithdrawRequests",  mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",                   item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",               ipAddress));

                    cmd.Parameters.Add(new SqlParameter("@TradingGUID",                 guid));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            requests.Add(request);
                            break;
                        case 2:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            requests.Add(request);
                            break;
                    }

                    mainDatabase.Close();

                    developmentResponse(requests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Settings(object token, string oldPassword, string newPassword)
        {
            var requests = new List<ApiServiceModel>();

            try
            {
                var js = new JavaScriptSerializer();
                string ipAddress = GetIpAddress();

                List<ApiServiceModel> getInfo = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var request = new ApiServiceModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                requests.Add(request);

                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_updateSettings",  mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;

                    foreach (var item in getInfo)
                    {
                        cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                    }

                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                    cmd.Parameters.Add(new SqlParameter("@OldPassword",     Aes(Operation.Encrypt, oldPassword)));
                    cmd.Parameters.Add(new SqlParameter("@NewPassword",     Aes(Operation.Encrypt, newPassword)));

                    mainDatabase.Open();

                    switch ((int)cmd.ExecuteScalar())
                    {
                        case 1:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "request is successfully",
                                status  = 1
                            };
                            requests.Add(request);
                            break;
                        case 2:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "your operation cannot be performed because your session has expired",
                                status  = 2
                            };
                            requests.Add(request);
                            break;
                        case 3:
                            requests.Clear();
                            request     = new ApiServiceModel
                            {
                                message = "request canceled due to incorrect password",
                                status  = 3
                            };
                            requests.Add(request);
                            break;
                    }

                    mainDatabase.Close();

                    developmentResponse(requests);
                }
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// Profile
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = true)]
        public void Profile(string userName)
        {
            var accounts    = new List<AccountsModel>();

            try
            {
                var account = new AccountsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                accounts.Add(account);

                SqlCommand cmd  = new SqlCommand("usp_getUserProfile",  mainDatabase);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(new SqlParameter("@UserName",        Aes(Operation.Encrypt, userName)));

                mainDatabase.Open();

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    if (dr.HasRows)
                    {
                        accounts.Clear();

                        account = new AccountsModel
                        {
                            UserName    = Aes(Operation.Decrypt, dr["UserName"].ToString()),
                            IsLoggedIn  = Convert.ToBoolean(dr["IsLoggedIn"]),
                            message     = "request is successfully",
                            status      = 1
                        };

                        accounts.Add(account);
                    }
                }

                dr.Close();
                mainDatabase.Close();

                developmentResponse(accounts);
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }

        /// <summary>
        /// Logout
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void Logout(object token)
        {
            var accounts = new List<AccountsModel>();

            try
            {
                var js                          = new JavaScriptSerializer();
                string ipAddress                = GetIpAddress();
                List<ApiServiceModel> getInfo   = JsonConvert.DeserializeObject<List<ApiServiceModel>>(js.Serialize(token));

                var account = new AccountsModel
                {
                    message = authenticationFailed,
                    status  = -1
                };

                accounts.Add(account);

                SqlCommand cmd  = new SqlCommand("usp_postLogout",      mainDatabase);
                cmd.CommandType = CommandType.StoredProcedure;

                foreach (var item in getInfo)
                {
                    cmd.Parameters.Add(new SqlParameter("@Token",       item.Token));
                }

                cmd.Parameters.Add(new SqlParameter("@LastIpAddress",   ipAddress));

                mainDatabase.Open();

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    accounts.Clear();

                    if (Convert.ToByte(dr["Result"]) == 1)
                    {
                        account = new AccountsModel
                        {
                            message = "successfully logged out of the account",
                            status  = 1
                        };
                    }
                    else
                    {
                        account = new AccountsModel
                        {
                            message = "request canceled due to unauthorized access",
                            status  = 2
                        };
                    }

                    accounts.Add(account);
                }

                dr.Close();
                mainDatabase.Close();

                developmentResponse(accounts);
            }
            catch
            {
                mainDatabase.Close();
                errorResponse();
            }
        }














































































































        // DEMO FOR ENCRYPTION AND DECRIPTION
        // DEMO FOR ENCRYPTION AND DECRIPTION
        // DEMO FOR ENCRYPTION AND DECRIPTION
        // DEMO FOR ENCRYPTION AND DECRIPTION
        // DEMO FOR ENCRYPTION AND DECRIPTION


        

























        /// <summary>
        /// AesOperation Shorter
        /// </summary>
        /// <param name="t">Encrypt or Decrypt type</param>
        /// <param name="value">value</param>
        /// <returns></returns>
        public string Aes(Operation type, string value)
        {
            try
            {
                if (type == 0)  return AesOperation.EncryptString(authKey, value);
                else            return AesOperation.DecryptString(authKey, value);
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// Aes Operation
        /// </summary>
        public enum Operation
        {
            Encrypt = 0,
            Decrypt = 1
        }

        /// <summary>
        /// for Google Recaptcha V3 model
        /// </summary>
        public class TokenResponse
        {
            [JsonProperty("success")]
            public bool         Success     { get; set; }

            [JsonProperty("score")]
            public decimal      Score       { get; set; }

            [JsonProperty("action")]
            public string       Action      { get; set; }

            [JsonProperty("error-codes")]
            public List<string> ErrorCodes  { get; set; }
        }

        /// <summary>
        /// google recaptcha v3
        /// </summary>
        /// <param name="token">verify token</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json, UseHttpGet = false)]
        public void RecaptchaV3Vverify(string token)
        {
            try {
                if (!(string.IsNullOrEmpty(token)))
                {
                    var client      = new WebClient();
                    var secret      = ConfigurationManager.AppSettings["RecaptchaV3SecretKey"];
                    var googleReply = client.DownloadString(string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", secret, token));
                    var serializer  = new JavaScriptSerializer();
                    var reCaptcha   = serializer.Deserialize<TokenResponse>(googleReply);
                    developmentResponse(reCaptcha);
                }
                else errorResponse();
            }
            catch
            {
                errorResponse();
            }
        }

        /// <summary>
        /// Development Response
        /// </summary>
        /// <param name="array"></param>
        /// <param name="contentLength"></param>
        public void developmentResponse(object array)
        {
            try
            {
                var result = JsonConvert.SerializeObject(array, Formatting.None,
                new JsonSerializerSettings
                {
                    DefaultValueHandling    = DefaultValueHandling.Ignore,
                    NullValueHandling       = NullValueHandling.Ignore,
                    StringEscapeHandling    = StringEscapeHandling.EscapeNonAscii
                });

                Context.Response.Clear();
                Context.Response.ContentType = "application/json";
                Context.Response.AddHeader("content-length", result.Length.ToString());
                Context.Response.Write(result);
                Context.Response.Flush();

            }
            catch
            {
                Context.Response.Clear();
                Context.Response.Write(serviceOffline);
            }
        }

        /// <summary>
        /// Build Api Error Response
        /// </summary>
        public void errorResponse()
        {
            try
            {
                // API Services Error Message
                var errorMessages   = new List<ApiServiceModel>();
                var errorMessage    = new ApiServiceModel
                {
                    message = serviceOffline,
                    status  = -1
                };
                errorMessages.Add(errorMessage);

                var result = JsonConvert.SerializeObject(errorMessages, Formatting.None,
                new JsonSerializerSettings
                {
                    DefaultValueHandling    = DefaultValueHandling.Ignore,
                    NullValueHandling       = NullValueHandling.Ignore,
                    StringEscapeHandling    = StringEscapeHandling.EscapeNonAscii
                });

                Context.Response.Clear();
                Context.Response.ContentType = "application/json";
                Context.Response.AddHeader("content-length", result.Length.ToString());
                Context.Response.Write(result);
                Context.Response.Flush();
            }
            catch
            {
                Context.Response.Clear();
                Context.Response.Write(serviceOffline);
            }
        }
    }
}
