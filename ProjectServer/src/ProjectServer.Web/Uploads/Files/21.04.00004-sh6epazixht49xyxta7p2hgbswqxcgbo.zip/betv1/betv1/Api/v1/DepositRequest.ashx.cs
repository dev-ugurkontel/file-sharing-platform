﻿using betv1.Libraries;
using betv1.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using static betv1.Libraries.DatabaseConnection;
using static betv1.Libraries.ExternalFunctions;

namespace betv1.Api.v1
{
    /// <summary>
    /// Summary description for DepositRequest
    /// </summary>
    public class DepositRequest : IHttpHandler
    {
        // Database Connections
        SqlConnection mainDatabase = new DatabaseConnection().Connect(Database.Main);

        string authenticationFailed = "authentication failed";
        string serviceOffline       = "api v1 services are now offline";
        string requestFailed        = "requuest failed";

        /// <summary>
        /// ApiServiceForDepositRequestModel
        /// </summary>
        public class ApiServiceForDepositRequestModel
        {
            public string message { get; set; }
            public int status { get; set; }
            public string TradingIBAN { get; set; }
            public decimal TradingAmount { get; set; }
            public string TradingHour { get; set; }
            public string TradingImagePath { get; set; }
            public string Token { get; set; }
        }

        /// <summary>
        /// ProcessRequest
        /// </summary>
        /// <param name="context">context</param>
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";

            try
            {
                bool clearCheck = true;
                var deposits = new List<ApiServiceForDepositRequestModel>();

                var deposit = new ApiServiceForDepositRequestModel
                {
                    message = requestFailed,
                    status = -1
                };

                deposits.Add(deposit);

                foreach (string s in context.Request.Files)
                {
                    //! Gelen dosya
                    HttpPostedFile file = context.Request.Files[s];

                    //! Dosya Uzantı ve Mimesini Tespit Et
                    string fileExt = Path.GetExtension(file.FileName);
                    string fileMime = file.ContentType;

                    //! Fotoğraf Uzantı ve Mime Tipleri Değişkenleri
                    string[] imgExts = { ".jpe", ".JPE", ".jpg", ".JPG", ".jpeg", ".JPEG", ".png", ".PNG" };
                    string[] imgMimes = { "image/jpeg", "image/jpg", "image/png" };

                    if (imgExts.Contains(fileExt) && imgMimes.Contains(fileMime))
                    {
                        if (!string.IsNullOrEmpty(fileExt))
                        {
                            string imgPath = HttpContext.Current.Server.MapPath("~/content/v1/uploads/deposit/");
                            string imgName = (GenerateUrl(96) + fileExt);

                            // dosyaayı kaydet
                            file.SaveAs(imgPath + imgName);

                            var js = new JavaScriptSerializer();

                            string tradingIBAN = context.Request.Form.Get("tradingIBAN");
                            decimal tradingAmount = Convert.ToDecimal(context.Request.Form.Get("tradingAmount"));
                            string tradingHour = context.Request.Form.Get("tradingHour");
                            string token = "";

                            List<ApiServiceForDepositRequestModel> getInfo4 = JsonConvert.DeserializeObject<List<ApiServiceForDepositRequestModel>>(context.Request.Form.Get("token"));
                            foreach (var item4 in getInfo4)
                            {
                                token = item4.Token;
                            }

                            if (clearCheck) deposits.Clear();

                            //! Veritabanına Kaydet
                            if (DatabaseSave(tradingIBAN, tradingAmount, tradingHour, imgName, token) == 1)
                            {
                                deposit = new ApiServiceForDepositRequestModel
                                {
                                    message = "request is successfully",
                                    status = 1
                                };
                            }
                            else
                            {
                                deposit = new ApiServiceForDepositRequestModel
                                {
                                    message = authenticationFailed,
                                    status = 2
                                };
                            }

                            deposits.Add(deposit);

                            clearCheck = false;
                        }
                    }
                }
                developmentResponse(context, deposits);
            }
            catch
            {
                mainDatabase.Close();
                errorResponse(context);
            }
        }

        /// <summary>
        /// DatabaseSave
        /// </summary>
        /// <param name="token">token</param>
        /// <param name="imgName">imgName</param>
        /// <returns></returns>
        public int DatabaseSave(string  tradingIBAN, 
                                decimal tradingAmount, 
                                string  tradingHour, 
                                string  tradingImagePath, 
                                string  token)
        {
            int result = 0;
            try
            {
                using (mainDatabase)
                {
                    SqlCommand cmd  = new SqlCommand("usp_postDepositRequest",  mainDatabase);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@TradingIBAN",         tradingIBAN));
                    cmd.Parameters.Add(new SqlParameter("@TradingAmount",       tradingAmount));
                    cmd.Parameters.Add(new SqlParameter("@TradingHour",         tradingHour));
                    cmd.Parameters.Add(new SqlParameter("@TradingImagePath",    tradingImagePath));
                    cmd.Parameters.Add(new SqlParameter("@Token",               token));
                    cmd.Parameters.Add(new SqlParameter("@LastIpAddress",       GetIpAddress()));
                    mainDatabase.Open();
                    result = (int)cmd.ExecuteScalar();
                    mainDatabase.Close();
                }
            }
            catch
            {
                mainDatabase.Close();
                result = -1;
            }
            return result;
        }

        /// <summary>
        /// Development Response
        /// </summary>
        /// <param name="context"></param>
        /// <param name="contentLength"></param>
        public void developmentResponse(HttpContext context, object array)
        {
            try
            {
                var result = JsonConvert.SerializeObject(array, Formatting.None,
                new JsonSerializerSettings
                {
                    DefaultValueHandling    = DefaultValueHandling.Ignore,
                    NullValueHandling       = NullValueHandling.Ignore,
                    StringEscapeHandling    = StringEscapeHandling.EscapeNonAscii
                });

                context.Response.Clear();
                context.Response.ContentType = "application/json";
                context.Response.AddHeader("content-length", result.Length.ToString());
                context.Response.Write(result);
                context.Response.Flush();

            }
            catch
            {
                context.Response.Clear();
                context.Response.Write(serviceOffline);
            }
        }

        public void errorResponse(HttpContext context)
        {
            try
            {
                // API Services Error Message
                var errorMessages   = new List<ApiServiceModel>();
                var errorMessage    = new ApiServiceModel
                {
                    message = serviceOffline,
                    status  = -1
                };
                errorMessages.Add(errorMessage);

                var result = JsonConvert.SerializeObject(errorMessages, Formatting.None,
                new JsonSerializerSettings
                {
                    DefaultValueHandling    = DefaultValueHandling.Ignore,
                    NullValueHandling       = NullValueHandling.Ignore,
                    StringEscapeHandling    = StringEscapeHandling.EscapeNonAscii
                });

                context.Response.Clear();
                context.Response.ContentType = "application/json";
                context.Response.AddHeader("content-length", result.Length.ToString());
                context.Response.Write(result);
                context.Response.Flush();
            }
            catch
            {
                context.Response.Clear();
                context.Response.Write(serviceOffline);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}