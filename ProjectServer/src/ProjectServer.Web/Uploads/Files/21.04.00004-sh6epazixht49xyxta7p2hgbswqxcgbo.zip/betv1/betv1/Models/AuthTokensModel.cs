﻿using System;

namespace betv1.Models
{
    public class AuthTokensModel
    {
        public long     ID              { get; set; }
        public int      AccountID       { get; set; }
        public string   Token           { get; set; }
        public string   LastIpAddress   { get; set; }
        public DateTime ExpiredDate     { get; set; }
    }
}