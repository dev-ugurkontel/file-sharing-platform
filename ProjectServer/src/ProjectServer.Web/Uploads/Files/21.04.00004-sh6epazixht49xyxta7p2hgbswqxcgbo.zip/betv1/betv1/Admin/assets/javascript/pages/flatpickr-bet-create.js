'use strict';
var flatpickrDemo = {
  init: function init() {

    this.bindUIActions();
  },
  bindUIActions: function bindUIActions() {

    // event handlers
    this.handleFlatpickr();
  },
  _fp1: function _fp2() {
    // DateTime
    return flatpickr('#betEndDate', {
        disableMobile: true, // always use the non-native picker
        enableTime: true,
        dateFormat: 'Z',
        time_24hr: true,
        locale: 'tr'
    });
  },
  handleFlatpickr: function handleFlatpickr() {
    this._fp1();
  }
};
flatpickrDemo.init();