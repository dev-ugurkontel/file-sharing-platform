﻿using System;

namespace betv1.Models
{
    public class AdminsModel : ApiServiceModel
    {
        public int      ID              { get; set; }
        public string   EMail           { get; set; }
        public string   HashPassword    { get; set; }
        public string   HashPin         { get; set; }
        public byte     AdminRole       { get; set; }
        public DateTime RegisteredDate  { get; set; }
    }
}