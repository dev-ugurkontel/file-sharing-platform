﻿using System;

namespace betv1.Models
{
    public class LoginHistoriesModel : ApiServiceModel
    {
        public long     ID              { get; set; }
        public int      AccountID       { get; set; }
        public string   IpAddress       { get; set; }
        public string   RequestData     { get; set; }
        public DateTime LastLoginDate   { get; set; }

        // Others
        public string   AccountGUID     { get; set; }
    }
}