﻿using System;

namespace betv1.Models
{
    public class BetTypesModel
    {
        public byte     ID                  { get; set; }
        public string   BetName             { get; set; }
        public decimal  BetTypeCommission   { get; set; }
        public DateTime LastUpdateDate      { get; set; }

        // DataTables
        public string   LastUpdateDateStr   { get; set; }
    }
}