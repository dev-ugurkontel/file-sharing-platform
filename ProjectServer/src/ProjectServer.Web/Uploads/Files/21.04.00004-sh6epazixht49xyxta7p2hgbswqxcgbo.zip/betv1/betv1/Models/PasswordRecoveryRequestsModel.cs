﻿using System;

namespace betv1.Models
{
    public class PasswordRecoveryRequestsModel
    {
        public int      ID          { get; set; }
        public int      AccountID   { get; set; }
        public string   RequestData { get; set; }
        public DateTime RequestDate { get; set; }
    }
}