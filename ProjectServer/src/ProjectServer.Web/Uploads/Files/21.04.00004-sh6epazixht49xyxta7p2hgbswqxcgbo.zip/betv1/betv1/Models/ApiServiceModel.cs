﻿using System;

namespace betv1.Models
{
    public class ApiServiceModel
    {
        public string   message                         { get; set; }
        public Int16    status                          { get; set; }
        public string   Token                           { get; set; }
        public DateTime ExpiredDate                     { get; set; }
        public long     ActiveFootballCompetitions      { get; set; }
        public long     ActiveBasketballCompetitions    { get; set; }

        // Others
        public int      TotalAccount                    { get; set; }
        public int      TotalActiveAccount              { get; set; }
        public int      TotalBannedAccount              { get; set; }
    }
}