﻿using System;
using System.Web;
using System.Web.UI;

namespace betv1
{
    public partial class Main : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var l = (HttpContext.Current.Request.Url.LocalPath);
            if (l.StartsWith("/account"))
            {
                if (l.Equals("/account/login") && !l.Equals("/account/register")) l = "login page";
                else if (l.Equals("/account/register") && !l.Equals("/account/login")) l = "register page";
                else body.Attributes.Add("style", "display: none");
            }        
        }
    }
}